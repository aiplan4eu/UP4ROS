// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Timepoint = require('./Timepoint.js');
let Real = require('./Real.js');

//-----------------------------------------------------------

class Timing {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timepoint = null;
      this.delay = null;
    }
    else {
      if (initObj.hasOwnProperty('timepoint')) {
        this.timepoint = initObj.timepoint
      }
      else {
        this.timepoint = new Timepoint();
      }
      if (initObj.hasOwnProperty('delay')) {
        this.delay = initObj.delay
      }
      else {
        this.delay = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Timing
    // Serialize message field [timepoint]
    bufferOffset = Timepoint.serialize(obj.timepoint, buffer, bufferOffset);
    // Serialize message field [delay]
    // Serialize the length for message field [delay]
    bufferOffset = _serializer.uint32(obj.delay.length, buffer, bufferOffset);
    obj.delay.forEach((val) => {
      bufferOffset = Real.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Timing
    let len;
    let data = new Timing(null);
    // Deserialize message field [timepoint]
    data.timepoint = Timepoint.deserialize(buffer, bufferOffset);
    // Deserialize message field [delay]
    // Deserialize array length for message field [delay]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.delay = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.delay[i] = Real.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Timepoint.getMessageSize(object.timepoint);
    length += 16 * object.delay.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Timing';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd4aacaa1c6bc10a3e7aa849070a5f8cf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Timing(null);
    if (msg.timepoint !== undefined) {
      resolved.timepoint = Timepoint.Resolve(msg.timepoint)
    }
    else {
      resolved.timepoint = new Timepoint()
    }

    if (msg.delay !== undefined) {
      resolved.delay = new Array(msg.delay.length);
      for (let i = 0; i < resolved.delay.length; ++i) {
        resolved.delay[i] = Real.Resolve(msg.delay[i]);
      }
    }
    else {
      resolved.delay = []
    }

    return resolved;
    }
};

module.exports = Timing;
