// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Expression = require('./Expression.js');

//-----------------------------------------------------------

class EffectExpression {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.kind = null;
      this.fluent = null;
      this.value = null;
      this.condition = null;
    }
    else {
      if (initObj.hasOwnProperty('kind')) {
        this.kind = initObj.kind
      }
      else {
        this.kind = 0;
      }
      if (initObj.hasOwnProperty('fluent')) {
        this.fluent = initObj.fluent
      }
      else {
        this.fluent = new Expression();
      }
      if (initObj.hasOwnProperty('value')) {
        this.value = initObj.value
      }
      else {
        this.value = new Expression();
      }
      if (initObj.hasOwnProperty('condition')) {
        this.condition = initObj.condition
      }
      else {
        this.condition = new Expression();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type EffectExpression
    // Serialize message field [kind]
    bufferOffset = _serializer.uint8(obj.kind, buffer, bufferOffset);
    // Serialize message field [fluent]
    bufferOffset = Expression.serialize(obj.fluent, buffer, bufferOffset);
    // Serialize message field [value]
    bufferOffset = Expression.serialize(obj.value, buffer, bufferOffset);
    // Serialize message field [condition]
    bufferOffset = Expression.serialize(obj.condition, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type EffectExpression
    let len;
    let data = new EffectExpression(null);
    // Deserialize message field [kind]
    data.kind = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [fluent]
    data.fluent = Expression.deserialize(buffer, bufferOffset);
    // Deserialize message field [value]
    data.value = Expression.deserialize(buffer, bufferOffset);
    // Deserialize message field [condition]
    data.condition = Expression.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Expression.getMessageSize(object.fluent);
    length += Expression.getMessageSize(object.value);
    length += Expression.getMessageSize(object.condition);
    return length + 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/EffectExpression';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd02d97c3cb75c57650ac5bd5dc0da30b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## An effect expression is of the form `FLUENT OP VALUE`.
    ## We explicitly restrict the different types of effects by setting the allowed operators.
    
    # The `fluent` is set to the corresponding `value`
    uint8 ASSIGN=0
    # The `fluent` is increased by the amount `value`
    # features: INCREASE_EFFECTS
    uint8 INCREASE=1
    # The `fluent` is decreased by the amount `value`
    # features: DECREASE_EFFECTS
    uint8 DECREASE=2
    
    uint8 kind
    
    # Expression that must be of the STATE_VARIABLE kind.
    up_msgs/Expression fluent
    up_msgs/Expression value
    
    # Optional. If the effect is conditional, then the following field must be set.
    # In this case, the `effect` will only be applied if the `condition`` holds.
    # If the effect is unconditional, the effect is set to the constant 'true' value.
    # features: CONDITIONAL_EFFECT
    up_msgs/Expression condition
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new EffectExpression(null);
    if (msg.kind !== undefined) {
      resolved.kind = msg.kind;
    }
    else {
      resolved.kind = 0
    }

    if (msg.fluent !== undefined) {
      resolved.fluent = Expression.Resolve(msg.fluent)
    }
    else {
      resolved.fluent = new Expression()
    }

    if (msg.value !== undefined) {
      resolved.value = Expression.Resolve(msg.value)
    }
    else {
      resolved.value = new Expression()
    }

    if (msg.condition !== undefined) {
      resolved.condition = Expression.Resolve(msg.condition)
    }
    else {
      resolved.condition = new Expression()
    }

    return resolved;
    }
};

// Constants for message
EffectExpression.Constants = {
  ASSIGN: 0,
  INCREASE: 1,
  DECREASE: 2,
}

module.exports = EffectExpression;
