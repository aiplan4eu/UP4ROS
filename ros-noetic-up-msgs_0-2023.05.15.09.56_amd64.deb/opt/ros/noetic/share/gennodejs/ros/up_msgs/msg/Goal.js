// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Expression = require('./Expression.js');
let TimeInterval = require('./TimeInterval.js');

//-----------------------------------------------------------

class Goal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.goal = null;
      this.timing = null;
    }
    else {
      if (initObj.hasOwnProperty('goal')) {
        this.goal = initObj.goal
      }
      else {
        this.goal = new Expression();
      }
      if (initObj.hasOwnProperty('timing')) {
        this.timing = initObj.timing
      }
      else {
        this.timing = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Goal
    // Serialize message field [goal]
    bufferOffset = Expression.serialize(obj.goal, buffer, bufferOffset);
    // Serialize message field [timing]
    // Serialize the length for message field [timing]
    bufferOffset = _serializer.uint32(obj.timing.length, buffer, bufferOffset);
    obj.timing.forEach((val) => {
      bufferOffset = TimeInterval.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Goal
    let len;
    let data = new Goal(null);
    // Deserialize message field [goal]
    data.goal = Expression.deserialize(buffer, bufferOffset);
    // Deserialize message field [timing]
    // Deserialize array length for message field [timing]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.timing = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.timing[i] = TimeInterval.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Expression.getMessageSize(object.goal);
    object.timing.forEach((val) => {
      length += TimeInterval.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Goal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '020bb09f6cc36b3e26b150b7f4467a1e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## A Goal is currently an expression that must hold either:
    ## - in the final state,
    ## - over a specific temporal interval (under the `timed_goals` features)
    
    # Goal expression that must hold in the final state.
    up_msgs/Expression goal
    
    # Optional. If specified the goal should hold over the specified temporal interval (instead of on the final state).
    # features: TIMED_GOALS
    up_msgs/TimeInterval[] timing
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/TimeInterval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Timing lower
    bool is_right_open
    up_msgs/Timing upper
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Goal(null);
    if (msg.goal !== undefined) {
      resolved.goal = Expression.Resolve(msg.goal)
    }
    else {
      resolved.goal = new Expression()
    }

    if (msg.timing !== undefined) {
      resolved.timing = new Array(msg.timing.length);
      for (let i = 0; i < resolved.timing.length; ++i) {
        resolved.timing[i] = TimeInterval.Resolve(msg.timing[i]);
      }
    }
    else {
      resolved.timing = []
    }

    return resolved;
    }
};

module.exports = Goal;
