// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let AbstractTaskDeclaration = require('./AbstractTaskDeclaration.js');
let Method = require('./Method.js');
let TaskNetwork = require('./TaskNetwork.js');

//-----------------------------------------------------------

class Hierarchy {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.abstract_tasks = null;
      this.methods = null;
      this.initial_task_network = null;
    }
    else {
      if (initObj.hasOwnProperty('abstract_tasks')) {
        this.abstract_tasks = initObj.abstract_tasks
      }
      else {
        this.abstract_tasks = [];
      }
      if (initObj.hasOwnProperty('methods')) {
        this.methods = initObj.methods
      }
      else {
        this.methods = [];
      }
      if (initObj.hasOwnProperty('initial_task_network')) {
        this.initial_task_network = initObj.initial_task_network
      }
      else {
        this.initial_task_network = new TaskNetwork();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Hierarchy
    // Serialize message field [abstract_tasks]
    // Serialize the length for message field [abstract_tasks]
    bufferOffset = _serializer.uint32(obj.abstract_tasks.length, buffer, bufferOffset);
    obj.abstract_tasks.forEach((val) => {
      bufferOffset = AbstractTaskDeclaration.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [methods]
    // Serialize the length for message field [methods]
    bufferOffset = _serializer.uint32(obj.methods.length, buffer, bufferOffset);
    obj.methods.forEach((val) => {
      bufferOffset = Method.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [initial_task_network]
    bufferOffset = TaskNetwork.serialize(obj.initial_task_network, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Hierarchy
    let len;
    let data = new Hierarchy(null);
    // Deserialize message field [abstract_tasks]
    // Deserialize array length for message field [abstract_tasks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.abstract_tasks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.abstract_tasks[i] = AbstractTaskDeclaration.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [methods]
    // Deserialize array length for message field [methods]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.methods = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.methods[i] = Method.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [initial_task_network]
    data.initial_task_network = TaskNetwork.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.abstract_tasks.forEach((val) => {
      length += AbstractTaskDeclaration.getMessageSize(val);
    });
    object.methods.forEach((val) => {
      length += Method.getMessageSize(val);
    });
    length += TaskNetwork.getMessageSize(object.initial_task_network);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Hierarchy';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7a83edb357eec7bb3ece7e5a76e7c87e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Represents the hierarchical part of a problem.
    ## features: hierarchical
    
    up_msgs/AbstractTaskDeclaration[] abstract_tasks
    up_msgs/Method[] methods
    up_msgs/TaskNetwork initial_task_network
    
    ================================================================================
    MSG: up_msgs/AbstractTaskDeclaration
    ## Declares an abstract task together with its expected parameters.
    ##
    ## Example: goto(robot: Robot, destination: Location)
    
    # Example: "goto"
    string name
    
    # Example:
    #  - robot: Robot
    #  - destination: Location
    up_msgs/Parameter[] parameters
    
    ================================================================================
    MSG: up_msgs/Parameter
    ## Parameter of a fluent or of an action
    
    # Name of the parameter.
    string name
    # Type of the parameter.
    string type
        
    ================================================================================
    MSG: up_msgs/Method
    # A method describes one possible way of achieving a task.
    #
    # Example: A method that make a "move" action and recursively calls itself until reaching the destination.
    
    # A name that uniquely identify the method.
    # This is mostly used for user facing output or plan validation.
    #
    # Example: "m-recursive-goto"
    string name
    
    # Example: [robot: Robot, source: Location, intermediate: Location, destination: Location]
    Parameter[] parameters
    
    # The task that is achieved by the method.
    # A subset of the parameters of the method will typically be used to
    # define the task that is achieved.
    #
    # Example: goto(robot, destination)
    up_msgs/Task achieved_task
    
    # A set of subtasks that should be achieved to carry out the method.
    # Note that the order of subtasks is irrelevant and that any ordering constraint should be
    # specified in the `constraints` field.
    #
    # Example:
    #  - t1: (move robot source intermediate)
    #  - t2: goto(robot destination)
    up_msgs/Task[] subtasks
    
    # Constraints enable the definition of ordering constraints as well as constraints
    # on the allowed instantiation of the method's parameters.
    #
    # Example:
    #  - end(t1) < start(t2)
    #  - source != intermediate
    up_msgs/Expression[] constraints
    
    # Conjunction of conditions that must hold for the method to be applicable.
    # As for the conditions of actions, these can be temporally qualified to refer to intermediate timepoints.
    # In addition to the start/end of the method, the temporal qualification might refer to the start/end of
    # one of the subtasks using its identifier.
    #
    # Example:
    #  - [start] loc(robot) == source
    #  - [end(t1)] loc(robot) == intermediate
    #  - [end] loc(robot) == destination
    up_msgs/Condition[] conditions
    
    ================================================================================
    MSG: up_msgs/Task
    ## Representation of an abstract or primitive task that should be achieved,
    ## required either in the initial task network or as a subtask of a method.
    ##
    ## Example:  task of sending a `robot` to the KITCHEN
    ##   - t1: goto(robot, KITCHEN)
    
    # Identifier of the task, required to be unique in the method/task-network where the task appears.
    # The `id` is notably used to refer to the start/end of the task.
    #
    # Example: t1
    string id
    
    # Name of the task that should be achieved. It might either
    #  - an abstract task if the name is the one of a task declared in the problem
    #  - a primitive task if the name is the one of an action declared in the problem
    #
    # Example:
    #  - "goto" (abstract task)
    #  - "move" (action / primitive task)
    string task_name
    
    # Example: (for a "goto" task)
    #  - robot    (a parameter from an outer scope)
    #  - KITCHEN  (a constant symbol in the problem)
    up_msgs/Expression[] parameters
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/Condition
    up_msgs/Expression cond
    
    # Optional. Must be set for durative actions where it specifies the temporal interval
    # over which when the condition should hold.
    # features: DURATIVE_ACTIONS
    up_msgs/TimeInterval[] span
    
    ================================================================================
    MSG: up_msgs/TimeInterval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Timing lower
    bool is_right_open
    up_msgs/Timing upper
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    ================================================================================
    MSG: up_msgs/TaskNetwork
    ## A task network defines a set of subtasks and associated constraints.
    ## It is intended to be used to define the initial task network of the hierarchical problem.
    ##
    ## Example: an arbitrary robot should go to the KITCHEN before time 100
    
    # robot: Location
    up_msgs/Parameter[] variables
    # t1: goto(robot, KITCHEN)
    up_msgs/Task[] subtasks
    # end(t1) <= 100
    up_msgs/Expression[] constraints
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Hierarchy(null);
    if (msg.abstract_tasks !== undefined) {
      resolved.abstract_tasks = new Array(msg.abstract_tasks.length);
      for (let i = 0; i < resolved.abstract_tasks.length; ++i) {
        resolved.abstract_tasks[i] = AbstractTaskDeclaration.Resolve(msg.abstract_tasks[i]);
      }
    }
    else {
      resolved.abstract_tasks = []
    }

    if (msg.methods !== undefined) {
      resolved.methods = new Array(msg.methods.length);
      for (let i = 0; i < resolved.methods.length; ++i) {
        resolved.methods[i] = Method.Resolve(msg.methods[i]);
      }
    }
    else {
      resolved.methods = []
    }

    if (msg.initial_task_network !== undefined) {
      resolved.initial_task_network = TaskNetwork.Resolve(msg.initial_task_network)
    }
    else {
      resolved.initial_task_network = new TaskNetwork()
    }

    return resolved;
    }
};

module.exports = Hierarchy;
