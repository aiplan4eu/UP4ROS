// Auto-generated. Do not edit!

// (in-package up_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Expression = require('../msg/Expression.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetInitialValueRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.problem_name = null;
      this.expression = null;
      this.value = null;
    }
    else {
      if (initObj.hasOwnProperty('problem_name')) {
        this.problem_name = initObj.problem_name
      }
      else {
        this.problem_name = '';
      }
      if (initObj.hasOwnProperty('expression')) {
        this.expression = initObj.expression
      }
      else {
        this.expression = new Expression();
      }
      if (initObj.hasOwnProperty('value')) {
        this.value = initObj.value
      }
      else {
        this.value = new Expression();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetInitialValueRequest
    // Serialize message field [problem_name]
    bufferOffset = _serializer.string(obj.problem_name, buffer, bufferOffset);
    // Serialize message field [expression]
    bufferOffset = Expression.serialize(obj.expression, buffer, bufferOffset);
    // Serialize message field [value]
    bufferOffset = Expression.serialize(obj.value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetInitialValueRequest
    let len;
    let data = new SetInitialValueRequest(null);
    // Deserialize message field [problem_name]
    data.problem_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [expression]
    data.expression = Expression.deserialize(buffer, bufferOffset);
    // Deserialize message field [value]
    data.value = Expression.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.problem_name);
    length += Expression.getMessageSize(object.expression);
    length += Expression.getMessageSize(object.value);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/SetInitialValueRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a8b1790383215e6a09aefa97c70e83b4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string problem_name
    up_msgs/Expression expression
    up_msgs/Expression value
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetInitialValueRequest(null);
    if (msg.problem_name !== undefined) {
      resolved.problem_name = msg.problem_name;
    }
    else {
      resolved.problem_name = ''
    }

    if (msg.expression !== undefined) {
      resolved.expression = Expression.Resolve(msg.expression)
    }
    else {
      resolved.expression = new Expression()
    }

    if (msg.value !== undefined) {
      resolved.value = Expression.Resolve(msg.value)
    }
    else {
      resolved.value = new Expression()
    }

    return resolved;
    }
};

class SetInitialValueResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetInitialValueResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetInitialValueResponse
    let len;
    let data = new SetInitialValueResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/SetInitialValueResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetInitialValueResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetInitialValueRequest,
  Response: SetInitialValueResponse,
  md5sum() { return '741d6600e2b4f7f3764b408799cd094e'; },
  datatype() { return 'up_msgs/SetInitialValue'; }
};
