// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LogMessage = require('./LogMessage.js');

//-----------------------------------------------------------

class ValidationResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
      this.log_messages = null;
      this.engine = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('log_messages')) {
        this.log_messages = initObj.log_messages
      }
      else {
        this.log_messages = [];
      }
      if (initObj.hasOwnProperty('engine')) {
        this.engine = initObj.engine
      }
      else {
        this.engine = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ValidationResult
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [log_messages]
    // Serialize the length for message field [log_messages]
    bufferOffset = _serializer.uint32(obj.log_messages.length, buffer, bufferOffset);
    obj.log_messages.forEach((val) => {
      bufferOffset = LogMessage.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [engine]
    bufferOffset = _serializer.string(obj.engine, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ValidationResult
    let len;
    let data = new ValidationResult(null);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [log_messages]
    // Deserialize array length for message field [log_messages]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.log_messages = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.log_messages[i] = LogMessage.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [engine]
    data.engine = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.log_messages.forEach((val) => {
      length += LogMessage.getMessageSize(val);
    });
    length += _getByteLength(object.engine);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/ValidationResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6ee98b9e794be8ff46db7ea671caa556';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Message sent by the validator.
    
    # The Plan is valid for the Problem.
    uint8 VALID=0
    # The Plan is not valid for the Problem.
    uint8 INVALID=0
    uint8 status
    
    # Optional. Information given by the engine to the user.
    up_msgs/LogMessage[] log_messages
    
    # Synthetic description of the engine that generated this message.
    string engine
    
    ================================================================================
    MSG: up_msgs/LogMessage
    ## A freely formatted logging message.
    ## Each message is annotated with its criticality level from the minimal (DEBUG) to the maximal (ERROR).
    ## Criticality level is expected to be used by an end user to decide the level of verbosity.
    
    uint8 DEBUG=0
    uint8 INFO=1
    uint8 WARNING=2
    uint8 ERROR=3
    
    uint8 level
    string message
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ValidationResult(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.log_messages !== undefined) {
      resolved.log_messages = new Array(msg.log_messages.length);
      for (let i = 0; i < resolved.log_messages.length; ++i) {
        resolved.log_messages[i] = LogMessage.Resolve(msg.log_messages[i]);
      }
    }
    else {
      resolved.log_messages = []
    }

    if (msg.engine !== undefined) {
      resolved.engine = msg.engine;
    }
    else {
      resolved.engine = ''
    }

    return resolved;
    }
};

// Constants for message
ValidationResult.Constants = {
  VALID: 0,
  INVALID: 0,
}

module.exports = ValidationResult;
