// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PDDLPlanRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mode = null;
      this.domain = null;
      this.problem = null;
      this.resolution_mode = null;
      this.timeout = null;
      this.engine_option_names = null;
      this.engine_option_values = null;
    }
    else {
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('domain')) {
        this.domain = initObj.domain
      }
      else {
        this.domain = '';
      }
      if (initObj.hasOwnProperty('problem')) {
        this.problem = initObj.problem
      }
      else {
        this.problem = '';
      }
      if (initObj.hasOwnProperty('resolution_mode')) {
        this.resolution_mode = initObj.resolution_mode
      }
      else {
        this.resolution_mode = 0;
      }
      if (initObj.hasOwnProperty('timeout')) {
        this.timeout = initObj.timeout
      }
      else {
        this.timeout = 0.0;
      }
      if (initObj.hasOwnProperty('engine_option_names')) {
        this.engine_option_names = initObj.engine_option_names
      }
      else {
        this.engine_option_names = '';
      }
      if (initObj.hasOwnProperty('engine_option_values')) {
        this.engine_option_values = initObj.engine_option_values
      }
      else {
        this.engine_option_values = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PDDLPlanRequest
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    // Serialize message field [domain]
    bufferOffset = _serializer.string(obj.domain, buffer, bufferOffset);
    // Serialize message field [problem]
    bufferOffset = _serializer.string(obj.problem, buffer, bufferOffset);
    // Serialize message field [resolution_mode]
    bufferOffset = _serializer.uint8(obj.resolution_mode, buffer, bufferOffset);
    // Serialize message field [timeout]
    bufferOffset = _serializer.float64(obj.timeout, buffer, bufferOffset);
    // Serialize message field [engine_option_names]
    bufferOffset = _serializer.string(obj.engine_option_names, buffer, bufferOffset);
    // Serialize message field [engine_option_values]
    bufferOffset = _serializer.string(obj.engine_option_values, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PDDLPlanRequest
    let len;
    let data = new PDDLPlanRequest(null);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [domain]
    data.domain = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [problem]
    data.problem = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [resolution_mode]
    data.resolution_mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [timeout]
    data.timeout = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [engine_option_names]
    data.engine_option_names = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [engine_option_values]
    data.engine_option_values = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.domain);
    length += _getByteLength(object.problem);
    length += _getByteLength(object.engine_option_names);
    length += _getByteLength(object.engine_option_values);
    return length + 26;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/PDDLPlanRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '79f84dc11ad249c563a5044c80c3228c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Problem that should be solved.
    
    # Specify if the domain/model string contains a file path, or the content
    uint8 FILE=0
    uint8 RAW=1
    uint8 mode
    
    string domain
    string problem
    
    uint8 SATISFIABLE=0
    uint8 SOLVED_OPTIMALLY=1
    uint8 resolution_mode
    
    # Max allowed runtime time in seconds.
    float64 timeout
    
    # Engine specific options to be passed to the engine
    string engine_option_names
    string engine_option_values
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PDDLPlanRequest(null);
    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.domain !== undefined) {
      resolved.domain = msg.domain;
    }
    else {
      resolved.domain = ''
    }

    if (msg.problem !== undefined) {
      resolved.problem = msg.problem;
    }
    else {
      resolved.problem = ''
    }

    if (msg.resolution_mode !== undefined) {
      resolved.resolution_mode = msg.resolution_mode;
    }
    else {
      resolved.resolution_mode = 0
    }

    if (msg.timeout !== undefined) {
      resolved.timeout = msg.timeout;
    }
    else {
      resolved.timeout = 0.0
    }

    if (msg.engine_option_names !== undefined) {
      resolved.engine_option_names = msg.engine_option_names;
    }
    else {
      resolved.engine_option_names = ''
    }

    if (msg.engine_option_values !== undefined) {
      resolved.engine_option_values = msg.engine_option_values;
    }
    else {
      resolved.engine_option_values = ''
    }

    return resolved;
    }
};

// Constants for message
PDDLPlanRequest.Constants = {
  FILE: 0,
  RAW: 1,
  SATISFIABLE: 0,
  SOLVED_OPTIMALLY: 1,
}

module.exports = PDDLPlanRequest;
