// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TypeDeclaration = require('./TypeDeclaration.js');
let Fluent = require('./Fluent.js');
let ObjectDeclaration = require('./ObjectDeclaration.js');
let Action = require('./Action.js');
let Assignment = require('./Assignment.js');
let TimedEffect = require('./TimedEffect.js');
let Goal = require('./Goal.js');
let Metric = require('./Metric.js');
let Hierarchy = require('./Hierarchy.js');

//-----------------------------------------------------------

class Problem {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.domain_name = null;
      this.problem_name = null;
      this.types = null;
      this.fluents = null;
      this.objects = null;
      this.actions = null;
      this.initial_state = null;
      this.timed_effects = null;
      this.goals = null;
      this.metrics = null;
      this.hierarchy = null;
      this.features = null;
    }
    else {
      if (initObj.hasOwnProperty('domain_name')) {
        this.domain_name = initObj.domain_name
      }
      else {
        this.domain_name = '';
      }
      if (initObj.hasOwnProperty('problem_name')) {
        this.problem_name = initObj.problem_name
      }
      else {
        this.problem_name = '';
      }
      if (initObj.hasOwnProperty('types')) {
        this.types = initObj.types
      }
      else {
        this.types = [];
      }
      if (initObj.hasOwnProperty('fluents')) {
        this.fluents = initObj.fluents
      }
      else {
        this.fluents = [];
      }
      if (initObj.hasOwnProperty('objects')) {
        this.objects = initObj.objects
      }
      else {
        this.objects = [];
      }
      if (initObj.hasOwnProperty('actions')) {
        this.actions = initObj.actions
      }
      else {
        this.actions = [];
      }
      if (initObj.hasOwnProperty('initial_state')) {
        this.initial_state = initObj.initial_state
      }
      else {
        this.initial_state = [];
      }
      if (initObj.hasOwnProperty('timed_effects')) {
        this.timed_effects = initObj.timed_effects
      }
      else {
        this.timed_effects = [];
      }
      if (initObj.hasOwnProperty('goals')) {
        this.goals = initObj.goals
      }
      else {
        this.goals = [];
      }
      if (initObj.hasOwnProperty('metrics')) {
        this.metrics = initObj.metrics
      }
      else {
        this.metrics = [];
      }
      if (initObj.hasOwnProperty('hierarchy')) {
        this.hierarchy = initObj.hierarchy
      }
      else {
        this.hierarchy = [];
      }
      if (initObj.hasOwnProperty('features')) {
        this.features = initObj.features
      }
      else {
        this.features = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Problem
    // Serialize message field [domain_name]
    bufferOffset = _serializer.string(obj.domain_name, buffer, bufferOffset);
    // Serialize message field [problem_name]
    bufferOffset = _serializer.string(obj.problem_name, buffer, bufferOffset);
    // Serialize message field [types]
    // Serialize the length for message field [types]
    bufferOffset = _serializer.uint32(obj.types.length, buffer, bufferOffset);
    obj.types.forEach((val) => {
      bufferOffset = TypeDeclaration.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [fluents]
    // Serialize the length for message field [fluents]
    bufferOffset = _serializer.uint32(obj.fluents.length, buffer, bufferOffset);
    obj.fluents.forEach((val) => {
      bufferOffset = Fluent.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [objects]
    // Serialize the length for message field [objects]
    bufferOffset = _serializer.uint32(obj.objects.length, buffer, bufferOffset);
    obj.objects.forEach((val) => {
      bufferOffset = ObjectDeclaration.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [actions]
    // Serialize the length for message field [actions]
    bufferOffset = _serializer.uint32(obj.actions.length, buffer, bufferOffset);
    obj.actions.forEach((val) => {
      bufferOffset = Action.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [initial_state]
    // Serialize the length for message field [initial_state]
    bufferOffset = _serializer.uint32(obj.initial_state.length, buffer, bufferOffset);
    obj.initial_state.forEach((val) => {
      bufferOffset = Assignment.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [timed_effects]
    // Serialize the length for message field [timed_effects]
    bufferOffset = _serializer.uint32(obj.timed_effects.length, buffer, bufferOffset);
    obj.timed_effects.forEach((val) => {
      bufferOffset = TimedEffect.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [goals]
    // Serialize the length for message field [goals]
    bufferOffset = _serializer.uint32(obj.goals.length, buffer, bufferOffset);
    obj.goals.forEach((val) => {
      bufferOffset = Goal.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [metrics]
    // Serialize the length for message field [metrics]
    bufferOffset = _serializer.uint32(obj.metrics.length, buffer, bufferOffset);
    obj.metrics.forEach((val) => {
      bufferOffset = Metric.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [hierarchy]
    // Serialize the length for message field [hierarchy]
    bufferOffset = _serializer.uint32(obj.hierarchy.length, buffer, bufferOffset);
    obj.hierarchy.forEach((val) => {
      bufferOffset = Hierarchy.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [features]
    bufferOffset = _arraySerializer.uint8(obj.features, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Problem
    let len;
    let data = new Problem(null);
    // Deserialize message field [domain_name]
    data.domain_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [problem_name]
    data.problem_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [types]
    // Deserialize array length for message field [types]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.types = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.types[i] = TypeDeclaration.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [fluents]
    // Deserialize array length for message field [fluents]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.fluents = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.fluents[i] = Fluent.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [objects]
    // Deserialize array length for message field [objects]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.objects = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.objects[i] = ObjectDeclaration.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [actions]
    // Deserialize array length for message field [actions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.actions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.actions[i] = Action.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [initial_state]
    // Deserialize array length for message field [initial_state]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.initial_state = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.initial_state[i] = Assignment.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [timed_effects]
    // Deserialize array length for message field [timed_effects]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.timed_effects = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.timed_effects[i] = TimedEffect.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [goals]
    // Deserialize array length for message field [goals]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.goals = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.goals[i] = Goal.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [metrics]
    // Deserialize array length for message field [metrics]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.metrics = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.metrics[i] = Metric.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [hierarchy]
    // Deserialize array length for message field [hierarchy]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.hierarchy = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.hierarchy[i] = Hierarchy.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [features]
    data.features = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.domain_name);
    length += _getByteLength(object.problem_name);
    object.types.forEach((val) => {
      length += TypeDeclaration.getMessageSize(val);
    });
    object.fluents.forEach((val) => {
      length += Fluent.getMessageSize(val);
    });
    object.objects.forEach((val) => {
      length += ObjectDeclaration.getMessageSize(val);
    });
    object.actions.forEach((val) => {
      length += Action.getMessageSize(val);
    });
    object.initial_state.forEach((val) => {
      length += Assignment.getMessageSize(val);
    });
    object.timed_effects.forEach((val) => {
      length += TimedEffect.getMessageSize(val);
    });
    object.goals.forEach((val) => {
      length += Goal.getMessageSize(val);
    });
    object.metrics.forEach((val) => {
      length += Metric.getMessageSize(val);
    });
    object.hierarchy.forEach((val) => {
      length += Hierarchy.getMessageSize(val);
    });
    length += object.features.length;
    return length + 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Problem';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '685ddac24fe2f1ab1ba618cc5c6cff05';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string domain_name
    string problem_name
    up_msgs/TypeDeclaration[] types
    up_msgs/Fluent[] fluents
    up_msgs/ObjectDeclaration[] objects
    
    # List of actions in the domain.
    up_msgs/Action[] actions
    
    # Initial state, including default values of state variables.
    up_msgs/Assignment[] initial_state
    
    # Facts and effects that are expected to occur strictly later than the initial state.
    # features: TIMED_EFFECT
    up_msgs/TimedEffect[] timed_effects
    
    # Goals of the planning problem.
    up_msgs/Goal[] goals
    
    # The plan quality metrics
    up_msgs/Metric[] metrics
    
    
    # If the problem is hierarchical, defines the tasks and methods as well as the initial task network.
    # features: hierarchical
    up_msgs/Hierarchy[] hierarchy
    
    # all features of the problem
    uint8[] features
    
    ## Features of the problem.
    ## Features are essential in that not supporting a feature `X` should allow disregarding any field tagged with `features: [X]`.
    
    # PROBLEM_CLASS
    uint8 ACTION_BASED=0
    uint8 HIERARCHICAL=26
    # PROBLEM_TYPE
    uint8 SIMPLE_NUMERIC_PLANNING=30
    uint8 GENERAL_NUMERIC_PLANNING=31
    # TIME
    uint8 CONTINUOUS_TIME=1
    uint8 DISCRETE_TIME=2
    uint8 INTERMEDIATE_CONDITIONS_AND_EFFECTS=3
    uint8 TIMED_EFFECT=4
    uint8 TIMED_GOALS=5
    uint8 DURATION_INEQUALITIES=6
    # EXPRESSION_DURATION
    uint8 STATIC_FLUENTS_IN_DURATIONS=27
    uint8 FLUENTS_IN_DURATIONS=28
    # NUMBERS
    uint8 CONTINUOUS_NUMBERS=7
    uint8 DISCRETE_NUMBERS=8
    uint8 BOUNDED_TYPES=38
    # CONDITIONS_KIND
    uint8 NEGATIVE_CONDITIONS=9
    uint8 DISJUNCTIVE_CONDITIONS=10
    uint8 EQUALITIES=11
    uint8 EXISTENTIAL_CONDITIONS=12
    uint8 UNIVERSAL_CONDITIONS=13
    # EFFECTS_KIND
    uint8 CONDITIONAL_EFFECTS=14
    uint8 INCREASE_EFFECTS=15
    uint8 DECREASE_EFFECTS=16
    uint8 STATIC_FLUENTS_IN_BOOLEAN_ASSIGNMENTS=41
    uint8 STATIC_FLUENTS_IN_NUMERIC_ASSIGNMENTS=42
    uint8 FLUENTS_IN_BOOLEAN_ASSIGNMENTS=43
    uint8 FLUENTS_IN_NUMERIC_ASSIGNMENTS=44
    # TYPING
    uint8 FLAT_TYPING=17
    uint8 HIERARCHICAL_TYPING=18
    # FLUENTS_TYPE
    uint8 NUMERIC_FLUENTS=19
    uint8 OBJECT_FLUENTS=20
    # QUALITY_METRICS
    uint8 ACTIONS_COST=21
    uint8 FINAL_VALUE=22
    uint8 MAKESPAN=23
    uint8 PLAN_LENGTH=24
    uint8 OVERSUBSCRIPTION=29
    # ACTION_COST_KIND
    uint8 STATIC_FLUENTS_IN_ACTIONS_COST=45
    uint8 FLUENTS_IN_ACTIONS_COST=46
    # SIMULATED_ENTITIES
    uint8 SIMULATED_EFFECTS=25
    
    ================================================================================
    MSG: up_msgs/TypeDeclaration
    ## Declares the existence of a symbolic type.
    
    # Name of the type that is declared.
    string type_name
    
    # Optional. If the string is non-empty, this is the parent type of `type_name`.
    # If set, the parent type must have been previously declared (i.e. should appear earlier in the problem's type declarations.
    # feature: HIERARCHICAL_TYPING
    string parent_type
    ================================================================================
    MSG: up_msgs/Fluent
    ## A state-dependent variable.
    
    string name
    # Return type of the fluent.
    string value_type
    # Typed and named parameters of the fluent.
    up_msgs/Parameter[] parameters
    
    # If non-empty, then any state variable using this fluent that is not explicitly given a value in the initial state
    # will be assumed to have this default value.
    # This allows mimicking the closed world assumption by setting a "false" default value to predicates.
    # Note that in the initial state of the problem message, it is assumed that all default values are set.
    up_msgs/Expression[] default_value
    
    ================================================================================
    MSG: up_msgs/Parameter
    ## Parameter of a fluent or of an action
    
    # Name of the parameter.
    string name
    # Type of the parameter.
    string type
        
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/ObjectDeclaration
    ## Declares an object with the given name and type.
    
    # Name of the object.
    string name 
    # Type of the object.
    # The type must have been previously declared in the problem definition.
    string type 
    
    ================================================================================
    MSG: up_msgs/Action
    ## Unified action representation that represents any kind of actions.
    
    # Action name. E.g. "move"
    string name
    
    # Typed and named parameters of the action.
    up_msgs/Parameter[] parameters
    
    # If set, the action is durative. Otherwise it is instantaneous.
    # features: DURATIVE_ACTIONS
    up_msgs/Duration[] duration
    
    # Conjunction of conditions that must hold for the action to be applicable.
    up_msgs/Condition[] conditions
    
    # Conjunction of effects as a result of applying this action.
    up_msgs/Effect[] effects
    
    ================================================================================
    MSG: up_msgs/Duration
    # The duration of the action can be freely chosen within the indicated bounds
    up_msgs/Interval controllable_in_bounds
    
    ================================================================================
    MSG: up_msgs/Interval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Expression lower
    bool is_right_open
    up_msgs/Expression upper
    
    ================================================================================
    MSG: up_msgs/Condition
    up_msgs/Expression cond
    
    # Optional. Must be set for durative actions where it specifies the temporal interval
    # over which when the condition should hold.
    # features: DURATIVE_ACTIONS
    up_msgs/TimeInterval[] span
    
    ================================================================================
    MSG: up_msgs/TimeInterval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Timing lower
    bool is_right_open
    up_msgs/Timing upper
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    ================================================================================
    MSG: up_msgs/Effect
    ## Representation of an effect that allows qualifying the effect expression, e.g., to make it a conditional effect.
    
    # Required. The actual effect that should take place.
    up_msgs/EffectExpression effect
    
    # Optional. If the effect is within a durative action, the following must be set and will specify when the effect takes place.
    # features: DURATIVE_ACTIONS
    up_msgs/Timing[] occurrence_time
    
    ================================================================================
    MSG: up_msgs/EffectExpression
    ## An effect expression is of the form `FLUENT OP VALUE`.
    ## We explicitly restrict the different types of effects by setting the allowed operators.
    
    # The `fluent` is set to the corresponding `value`
    uint8 ASSIGN=0
    # The `fluent` is increased by the amount `value`
    # features: INCREASE_EFFECTS
    uint8 INCREASE=1
    # The `fluent` is decreased by the amount `value`
    # features: DECREASE_EFFECTS
    uint8 DECREASE=2
    
    uint8 kind
    
    # Expression that must be of the STATE_VARIABLE kind.
    up_msgs/Expression fluent
    up_msgs/Expression value
    
    # Optional. If the effect is conditional, then the following field must be set.
    # In this case, the `effect` will only be applied if the `condition`` holds.
    # If the effect is unconditional, the effect is set to the constant 'true' value.
    # features: CONDITIONAL_EFFECT
    up_msgs/Expression condition
    
    ================================================================================
    MSG: up_msgs/Assignment
    ## An assignment of a value to a fluent, as it appears in the initial state definition.
    
    # State variable that is assigned the `value`.
    # It should be an expression of the STATE_VARIABLE kind for which all parameters are of the CONSTANT kind.
    up_msgs/Expression fluent
    # An expression of the CONSTANT kind, denoting the value take by the state variable.
    up_msgs/Expression value
    
    ================================================================================
    MSG: up_msgs/TimedEffect
    ## Represents an effect that will occur sometime beyond the initial state. (similar to timed initial literals)
    
    # Required. An effect expression that will take place sometime in the future (i.e. not at the intial state) as specified by the temporal qualifiation.
    up_msgs/EffectExpression effect
    # Required. Temporal qualification denoting when the timed fact will occur.
    up_msgs/Timing occurrence_time
    
    ================================================================================
    MSG: up_msgs/Goal
    ## A Goal is currently an expression that must hold either:
    ## - in the final state,
    ## - over a specific temporal interval (under the `timed_goals` features)
    
    # Goal expression that must hold in the final state.
    up_msgs/Expression goal
    
    # Optional. If specified the goal should hold over the specified temporal interval (instead of on the final state).
    # features: TIMED_GOALS
    up_msgs/TimeInterval[] timing
    
    ================================================================================
    MSG: up_msgs/Metric
    
    # Minimize the action costs expressed in the `action_costs` field
    uint8 MINIMIZE_ACTION_COSTS=0
    
    # Minimize the length of the resulting sequential plan
    uint8 MINIMIZE_SEQUENTIAL_PLAN_LENGTH=1
    
    # Minimize the makespan in case of temporal planning
    # features: durative_actions
    uint8 MINIMIZE_MAKESPAN=2
    
    # Minimize the value of the expression defined in the `expression` field
    uint8 MINIMIZE_EXPRESSION_ON_FINAL_STATE=3
    
    # Maximize the value of the expression defined in the `expression` field
    uint8 MAXIMIZE_EXPRESSION_ON_FINAL_STATE=4
    
    # Maximize the number of goals reached, weighted by cost
    uint8 OVERSUBSCRIPTION=5
        
    uint8 kind
    
    
    # Expression to minimize/maximize in the final state.
    # Empty, if the `kind` is not {MIN/MAX}IMIZE_EXPRESSION_ON_FINAL_STATE
    Expression expression
    
    # If `kind == MINIMIZE_ACTION_COSTS``, then each action is associated to a cost expression.
    #
    # TODO: Document what is allowed in the expression. See issue #134
    # In particular, for this metric to be useful in many practical problems, the cost expression
    # should allow referring to the action parameters (and possibly the current state at the action start/end).
    # This is very awkward to do in this setting where the expression is detached from its scope.
    string[] action_cost_names
    up_msgs/Expression[] action_cost_expr
    
    up_msgs/Expression[] default_action_cost
    
    # List of goals used to define the oversubscription planning problem.
    # Empty, if the `kind` is not OVERSUBSCRIPTION
    up_msgs/GoalWithCost[] goals
    ================================================================================
    MSG: up_msgs/GoalWithCost
    ## Represents a goal associated with a cost, used to define oversubscription planning.
    
    # Goal expression
    up_msgs/Expression goal
    # The cost
    up_msgs/Real cost
    
    ================================================================================
    MSG: up_msgs/Hierarchy
    ## Represents the hierarchical part of a problem.
    ## features: hierarchical
    
    up_msgs/AbstractTaskDeclaration[] abstract_tasks
    up_msgs/Method[] methods
    up_msgs/TaskNetwork initial_task_network
    
    ================================================================================
    MSG: up_msgs/AbstractTaskDeclaration
    ## Declares an abstract task together with its expected parameters.
    ##
    ## Example: goto(robot: Robot, destination: Location)
    
    # Example: "goto"
    string name
    
    # Example:
    #  - robot: Robot
    #  - destination: Location
    up_msgs/Parameter[] parameters
    
    ================================================================================
    MSG: up_msgs/Method
    # A method describes one possible way of achieving a task.
    #
    # Example: A method that make a "move" action and recursively calls itself until reaching the destination.
    
    # A name that uniquely identify the method.
    # This is mostly used for user facing output or plan validation.
    #
    # Example: "m-recursive-goto"
    string name
    
    # Example: [robot: Robot, source: Location, intermediate: Location, destination: Location]
    Parameter[] parameters
    
    # The task that is achieved by the method.
    # A subset of the parameters of the method will typically be used to
    # define the task that is achieved.
    #
    # Example: goto(robot, destination)
    up_msgs/Task achieved_task
    
    # A set of subtasks that should be achieved to carry out the method.
    # Note that the order of subtasks is irrelevant and that any ordering constraint should be
    # specified in the `constraints` field.
    #
    # Example:
    #  - t1: (move robot source intermediate)
    #  - t2: goto(robot destination)
    up_msgs/Task[] subtasks
    
    # Constraints enable the definition of ordering constraints as well as constraints
    # on the allowed instantiation of the method's parameters.
    #
    # Example:
    #  - end(t1) < start(t2)
    #  - source != intermediate
    up_msgs/Expression[] constraints
    
    # Conjunction of conditions that must hold for the method to be applicable.
    # As for the conditions of actions, these can be temporally qualified to refer to intermediate timepoints.
    # In addition to the start/end of the method, the temporal qualification might refer to the start/end of
    # one of the subtasks using its identifier.
    #
    # Example:
    #  - [start] loc(robot) == source
    #  - [end(t1)] loc(robot) == intermediate
    #  - [end] loc(robot) == destination
    up_msgs/Condition[] conditions
    
    ================================================================================
    MSG: up_msgs/Task
    ## Representation of an abstract or primitive task that should be achieved,
    ## required either in the initial task network or as a subtask of a method.
    ##
    ## Example:  task of sending a `robot` to the KITCHEN
    ##   - t1: goto(robot, KITCHEN)
    
    # Identifier of the task, required to be unique in the method/task-network where the task appears.
    # The `id` is notably used to refer to the start/end of the task.
    #
    # Example: t1
    string id
    
    # Name of the task that should be achieved. It might either
    #  - an abstract task if the name is the one of a task declared in the problem
    #  - a primitive task if the name is the one of an action declared in the problem
    #
    # Example:
    #  - "goto" (abstract task)
    #  - "move" (action / primitive task)
    string task_name
    
    # Example: (for a "goto" task)
    #  - robot    (a parameter from an outer scope)
    #  - KITCHEN  (a constant symbol in the problem)
    up_msgs/Expression[] parameters
    
    ================================================================================
    MSG: up_msgs/TaskNetwork
    ## A task network defines a set of subtasks and associated constraints.
    ## It is intended to be used to define the initial task network of the hierarchical problem.
    ##
    ## Example: an arbitrary robot should go to the KITCHEN before time 100
    
    # robot: Location
    up_msgs/Parameter[] variables
    # t1: goto(robot, KITCHEN)
    up_msgs/Task[] subtasks
    # end(t1) <= 100
    up_msgs/Expression[] constraints
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Problem(null);
    if (msg.domain_name !== undefined) {
      resolved.domain_name = msg.domain_name;
    }
    else {
      resolved.domain_name = ''
    }

    if (msg.problem_name !== undefined) {
      resolved.problem_name = msg.problem_name;
    }
    else {
      resolved.problem_name = ''
    }

    if (msg.types !== undefined) {
      resolved.types = new Array(msg.types.length);
      for (let i = 0; i < resolved.types.length; ++i) {
        resolved.types[i] = TypeDeclaration.Resolve(msg.types[i]);
      }
    }
    else {
      resolved.types = []
    }

    if (msg.fluents !== undefined) {
      resolved.fluents = new Array(msg.fluents.length);
      for (let i = 0; i < resolved.fluents.length; ++i) {
        resolved.fluents[i] = Fluent.Resolve(msg.fluents[i]);
      }
    }
    else {
      resolved.fluents = []
    }

    if (msg.objects !== undefined) {
      resolved.objects = new Array(msg.objects.length);
      for (let i = 0; i < resolved.objects.length; ++i) {
        resolved.objects[i] = ObjectDeclaration.Resolve(msg.objects[i]);
      }
    }
    else {
      resolved.objects = []
    }

    if (msg.actions !== undefined) {
      resolved.actions = new Array(msg.actions.length);
      for (let i = 0; i < resolved.actions.length; ++i) {
        resolved.actions[i] = Action.Resolve(msg.actions[i]);
      }
    }
    else {
      resolved.actions = []
    }

    if (msg.initial_state !== undefined) {
      resolved.initial_state = new Array(msg.initial_state.length);
      for (let i = 0; i < resolved.initial_state.length; ++i) {
        resolved.initial_state[i] = Assignment.Resolve(msg.initial_state[i]);
      }
    }
    else {
      resolved.initial_state = []
    }

    if (msg.timed_effects !== undefined) {
      resolved.timed_effects = new Array(msg.timed_effects.length);
      for (let i = 0; i < resolved.timed_effects.length; ++i) {
        resolved.timed_effects[i] = TimedEffect.Resolve(msg.timed_effects[i]);
      }
    }
    else {
      resolved.timed_effects = []
    }

    if (msg.goals !== undefined) {
      resolved.goals = new Array(msg.goals.length);
      for (let i = 0; i < resolved.goals.length; ++i) {
        resolved.goals[i] = Goal.Resolve(msg.goals[i]);
      }
    }
    else {
      resolved.goals = []
    }

    if (msg.metrics !== undefined) {
      resolved.metrics = new Array(msg.metrics.length);
      for (let i = 0; i < resolved.metrics.length; ++i) {
        resolved.metrics[i] = Metric.Resolve(msg.metrics[i]);
      }
    }
    else {
      resolved.metrics = []
    }

    if (msg.hierarchy !== undefined) {
      resolved.hierarchy = new Array(msg.hierarchy.length);
      for (let i = 0; i < resolved.hierarchy.length; ++i) {
        resolved.hierarchy[i] = Hierarchy.Resolve(msg.hierarchy[i]);
      }
    }
    else {
      resolved.hierarchy = []
    }

    if (msg.features !== undefined) {
      resolved.features = msg.features;
    }
    else {
      resolved.features = []
    }

    return resolved;
    }
};

// Constants for message
Problem.Constants = {
  ACTION_BASED: 0,
  HIERARCHICAL: 26,
  SIMPLE_NUMERIC_PLANNING: 30,
  GENERAL_NUMERIC_PLANNING: 31,
  CONTINUOUS_TIME: 1,
  DISCRETE_TIME: 2,
  INTERMEDIATE_CONDITIONS_AND_EFFECTS: 3,
  TIMED_EFFECT: 4,
  TIMED_GOALS: 5,
  DURATION_INEQUALITIES: 6,
  STATIC_FLUENTS_IN_DURATIONS: 27,
  FLUENTS_IN_DURATIONS: 28,
  CONTINUOUS_NUMBERS: 7,
  DISCRETE_NUMBERS: 8,
  BOUNDED_TYPES: 38,
  NEGATIVE_CONDITIONS: 9,
  DISJUNCTIVE_CONDITIONS: 10,
  EQUALITIES: 11,
  EXISTENTIAL_CONDITIONS: 12,
  UNIVERSAL_CONDITIONS: 13,
  CONDITIONAL_EFFECTS: 14,
  INCREASE_EFFECTS: 15,
  DECREASE_EFFECTS: 16,
  STATIC_FLUENTS_IN_BOOLEAN_ASSIGNMENTS: 41,
  STATIC_FLUENTS_IN_NUMERIC_ASSIGNMENTS: 42,
  FLUENTS_IN_BOOLEAN_ASSIGNMENTS: 43,
  FLUENTS_IN_NUMERIC_ASSIGNMENTS: 44,
  FLAT_TYPING: 17,
  HIERARCHICAL_TYPING: 18,
  NUMERIC_FLUENTS: 19,
  OBJECT_FLUENTS: 20,
  ACTIONS_COST: 21,
  FINAL_VALUE: 22,
  MAKESPAN: 23,
  PLAN_LENGTH: 24,
  OVERSUBSCRIPTION: 29,
  STATIC_FLUENTS_IN_ACTIONS_COST: 45,
  FLUENTS_IN_ACTIONS_COST: 46,
  SIMULATED_EFFECTS: 25,
}

module.exports = Problem;
