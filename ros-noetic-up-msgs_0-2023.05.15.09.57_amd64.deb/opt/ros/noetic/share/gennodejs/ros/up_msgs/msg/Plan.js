// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ActionInstance = require('./ActionInstance.js');

//-----------------------------------------------------------

class Plan {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.actions = null;
    }
    else {
      if (initObj.hasOwnProperty('actions')) {
        this.actions = initObj.actions
      }
      else {
        this.actions = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Plan
    // Serialize message field [actions]
    // Serialize the length for message field [actions]
    bufferOffset = _serializer.uint32(obj.actions.length, buffer, bufferOffset);
    obj.actions.forEach((val) => {
      bufferOffset = ActionInstance.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Plan
    let len;
    let data = new Plan(null);
    // Deserialize message field [actions]
    // Deserialize array length for message field [actions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.actions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.actions[i] = ActionInstance.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.actions.forEach((val) => {
      length += ActionInstance.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Plan';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '62ccc688b45fa42d7e5901dc1cd527da';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # An ordered sequence of actions that appear in the plan.
    # The order of the actions in the list must be compatible with the partial order of the start times.
    # In case of non-temporal planning, this allows having all start time at 0 and only rely on the order in this sequence.
        
    up_msgs/ActionInstance[] actions
    
    ================================================================================
    MSG: up_msgs/ActionInstance
    ## Representation of an action instance that appears in a plan.
    
    # Optional. A unique identifier of the action that might be used to refer to it (e.g. in HTN plans).
    string id
    # name of the action
    string action_name
    # Parameters of the action instance, required to be constants.
    up_msgs/Atom[] parameters
    
    bool time_triggered
    
    # Start time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real start_time
    # End time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real end_time
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Plan(null);
    if (msg.actions !== undefined) {
      resolved.actions = new Array(msg.actions.length);
      for (let i = 0; i < resolved.actions.length; ++i) {
        resolved.actions[i] = ActionInstance.Resolve(msg.actions[i]);
      }
    }
    else {
      resolved.actions = []
    }

    return resolved;
    }
};

module.exports = Plan;
