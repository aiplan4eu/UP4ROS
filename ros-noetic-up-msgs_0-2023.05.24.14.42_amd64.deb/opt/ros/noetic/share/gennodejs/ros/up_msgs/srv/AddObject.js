// Auto-generated. Do not edit!

// (in-package up_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ObjectDeclaration = require('../msg/ObjectDeclaration.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class AddObjectRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.problem_name = null;
      this.object = null;
    }
    else {
      if (initObj.hasOwnProperty('problem_name')) {
        this.problem_name = initObj.problem_name
      }
      else {
        this.problem_name = '';
      }
      if (initObj.hasOwnProperty('object')) {
        this.object = initObj.object
      }
      else {
        this.object = new ObjectDeclaration();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AddObjectRequest
    // Serialize message field [problem_name]
    bufferOffset = _serializer.string(obj.problem_name, buffer, bufferOffset);
    // Serialize message field [object]
    bufferOffset = ObjectDeclaration.serialize(obj.object, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AddObjectRequest
    let len;
    let data = new AddObjectRequest(null);
    // Deserialize message field [problem_name]
    data.problem_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [object]
    data.object = ObjectDeclaration.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.problem_name);
    length += ObjectDeclaration.getMessageSize(object.object);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/AddObjectRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b98e67d3e2b5a97b9035a1bc370bdf06';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string problem_name
    up_msgs/ObjectDeclaration object
    
    ================================================================================
    MSG: up_msgs/ObjectDeclaration
    ## Declares an object with the given name and type.
    
    # Name of the object.
    string name 
    # Type of the object.
    # The type must have been previously declared in the problem definition.
    string type 
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AddObjectRequest(null);
    if (msg.problem_name !== undefined) {
      resolved.problem_name = msg.problem_name;
    }
    else {
      resolved.problem_name = ''
    }

    if (msg.object !== undefined) {
      resolved.object = ObjectDeclaration.Resolve(msg.object)
    }
    else {
      resolved.object = new ObjectDeclaration()
    }

    return resolved;
    }
};

class AddObjectResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AddObjectResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AddObjectResponse
    let len;
    let data = new AddObjectResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/AddObjectResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AddObjectResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: AddObjectRequest,
  Response: AddObjectResponse,
  md5sum() { return 'f40542568b5a69b37cdb6fc545a1934f'; },
  datatype() { return 'up_msgs/AddObject'; }
};
