// Auto-generated. Do not edit!

// (in-package up_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PDDLPlanRequest = require('../msg/PDDLPlanRequest.js');

//-----------------------------------------------------------

let PlanGenerationResult = require('../msg/PlanGenerationResult.js');

//-----------------------------------------------------------

class PDDLPlanOneShotRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan_request = null;
    }
    else {
      if (initObj.hasOwnProperty('plan_request')) {
        this.plan_request = initObj.plan_request
      }
      else {
        this.plan_request = new PDDLPlanRequest();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PDDLPlanOneShotRequest
    // Serialize message field [plan_request]
    bufferOffset = PDDLPlanRequest.serialize(obj.plan_request, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PDDLPlanOneShotRequest
    let len;
    let data = new PDDLPlanOneShotRequest(null);
    // Deserialize message field [plan_request]
    data.plan_request = PDDLPlanRequest.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += PDDLPlanRequest.getMessageSize(object.plan_request);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/PDDLPlanOneShotRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dd8b4195ee92003b16605503108e8b5d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    up_msgs/PDDLPlanRequest plan_request
    
    ================================================================================
    MSG: up_msgs/PDDLPlanRequest
    # Problem that should be solved.
    
    # Specify if the domain/model string contains a file path, or the content
    uint8 FILE=0
    uint8 RAW=1
    uint8 mode
    
    string domain
    string problem
    
    uint8 SATISFIABLE=0
    uint8 SOLVED_OPTIMALLY=1
    uint8 resolution_mode
    
    # Max allowed runtime time in seconds.
    float64 timeout
    
    # Engine specific options to be passed to the engine
    string engine_option_names
    string engine_option_values
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PDDLPlanOneShotRequest(null);
    if (msg.plan_request !== undefined) {
      resolved.plan_request = PDDLPlanRequest.Resolve(msg.plan_request)
    }
    else {
      resolved.plan_request = new PDDLPlanRequest()
    }

    return resolved;
    }
};

class PDDLPlanOneShotResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan_result = null;
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('plan_result')) {
        this.plan_result = initObj.plan_result
      }
      else {
        this.plan_result = new PlanGenerationResult();
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PDDLPlanOneShotResponse
    // Serialize message field [plan_result]
    bufferOffset = PlanGenerationResult.serialize(obj.plan_result, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PDDLPlanOneShotResponse
    let len;
    let data = new PDDLPlanOneShotResponse(null);
    // Deserialize message field [plan_result]
    data.plan_result = PlanGenerationResult.deserialize(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += PlanGenerationResult.getMessageSize(object.plan_result);
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/PDDLPlanOneShotResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8908d5f75292b637790628ed2fba201';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    up_msgs/PlanGenerationResult plan_result
    bool success
    string message
    
    
    ================================================================================
    MSG: up_msgs/PlanGenerationResult
    ## Message sent by engine.
    ## Contains the engine exit status as well as the best plan found if any.
    
    
    # ==== Engine stopped normally ======
    
    # Valid plan found
    # The `plan` field must be set.
    uint8 SOLVED_SATISFICING=0
    # Plan found with optimality guarantee
    # The `plan` field must be set and contains an optimal solution.
    uint8 SOLVED_OPTIMALLY=1
    # No plan exists
    uint8 UNSOLVABLE_PROVEN=2
    # The engine was not able to find a solution but does not give any guarantee that none exist
    # (i.e. the engine might not be complete)
    uint8 UNSOLVABLE_INCOMPLETELY=3
    
    # ====== Engine exited before making any conclusion ====
    # Search stopped before concluding SOLVED_OPTIMALLY or UNSOLVABLE_PROVEN
    # If a plan was found, it might be reported in the `plan` field
    
    # The engine ran out of time
    uint8 TIMEOUT=13
    # The engine ran out of memory
    uint8 MEMOUT=14
    # The engine faced an internal error.
    uint8 INTERNAL_ERROR=15
    # The problem submitted is not supported by the engine.
    uint8 UNSUPPORTED_PROBLEM=16
    
    # ====== Intermediate answer ======
    # This Answer is an Intermediate Answer and not a Final one
    uint8 INTERMEDIATE=17
    
    uint8 status
    
    # Optional. Best plan found if any.
    up_msgs/Plan plan
    
    # A set of engine specific values that can be reported, for instance
    # - "grounding-time": "10ms"
    # - "expanded-states": "1290"
    string[] metric_names
    string[] metric_values
    
    # Optional log messages about the engine's activity.
    # Note that it should not be expected that logging messages are visible to the end user.
    # If used in conjunction with INTERNAL_ERROR or UNSUPPORTED_PROBLEM, it would be expected to have at least one log message at the ERROR level.
    up_msgs/LogMessage[] log_messages
    
    # Synthetic description of the engine that generated this message.
    string engine_name
    
    ================================================================================
    MSG: up_msgs/Plan
    # An ordered sequence of actions that appear in the plan.
    # The order of the actions in the list must be compatible with the partial order of the start times.
    # In case of non-temporal planning, this allows having all start time at 0 and only rely on the order in this sequence.
        
    up_msgs/ActionInstance[] actions
    
    ================================================================================
    MSG: up_msgs/ActionInstance
    ## Representation of an action instance that appears in a plan.
    
    # Optional. A unique identifier of the action that might be used to refer to it (e.g. in HTN plans).
    string id
    # name of the action
    string action_name
    # Parameters of the action instance, required to be constants.
    up_msgs/Atom[] parameters
    
    bool time_triggered
    
    # Start time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real start_time
    # End time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real end_time
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/LogMessage
    ## A freely formatted logging message.
    ## Each message is annotated with its criticality level from the minimal (DEBUG) to the maximal (ERROR).
    ## Criticality level is expected to be used by an end user to decide the level of verbosity.
    
    uint8 DEBUG=0
    uint8 INFO=1
    uint8 WARNING=2
    uint8 ERROR=3
    
    uint8 level
    string message
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PDDLPlanOneShotResponse(null);
    if (msg.plan_result !== undefined) {
      resolved.plan_result = PlanGenerationResult.Resolve(msg.plan_result)
    }
    else {
      resolved.plan_result = new PlanGenerationResult()
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: PDDLPlanOneShotRequest,
  Response: PDDLPlanOneShotResponse,
  md5sum() { return 'c3cae159ce75ac52d51c77656d09e762'; },
  datatype() { return 'up_msgs/PDDLPlanOneShot'; }
};
