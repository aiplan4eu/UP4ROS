// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Parameter = require('./Parameter.js');
let Task = require('./Task.js');
let Expression = require('./Expression.js');
let Condition = require('./Condition.js');

//-----------------------------------------------------------

class Method {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.parameters = null;
      this.achieved_task = null;
      this.subtasks = null;
      this.constraints = null;
      this.conditions = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('parameters')) {
        this.parameters = initObj.parameters
      }
      else {
        this.parameters = [];
      }
      if (initObj.hasOwnProperty('achieved_task')) {
        this.achieved_task = initObj.achieved_task
      }
      else {
        this.achieved_task = new Task();
      }
      if (initObj.hasOwnProperty('subtasks')) {
        this.subtasks = initObj.subtasks
      }
      else {
        this.subtasks = [];
      }
      if (initObj.hasOwnProperty('constraints')) {
        this.constraints = initObj.constraints
      }
      else {
        this.constraints = [];
      }
      if (initObj.hasOwnProperty('conditions')) {
        this.conditions = initObj.conditions
      }
      else {
        this.conditions = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Method
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [parameters]
    // Serialize the length for message field [parameters]
    bufferOffset = _serializer.uint32(obj.parameters.length, buffer, bufferOffset);
    obj.parameters.forEach((val) => {
      bufferOffset = Parameter.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [achieved_task]
    bufferOffset = Task.serialize(obj.achieved_task, buffer, bufferOffset);
    // Serialize message field [subtasks]
    // Serialize the length for message field [subtasks]
    bufferOffset = _serializer.uint32(obj.subtasks.length, buffer, bufferOffset);
    obj.subtasks.forEach((val) => {
      bufferOffset = Task.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [constraints]
    // Serialize the length for message field [constraints]
    bufferOffset = _serializer.uint32(obj.constraints.length, buffer, bufferOffset);
    obj.constraints.forEach((val) => {
      bufferOffset = Expression.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [conditions]
    // Serialize the length for message field [conditions]
    bufferOffset = _serializer.uint32(obj.conditions.length, buffer, bufferOffset);
    obj.conditions.forEach((val) => {
      bufferOffset = Condition.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Method
    let len;
    let data = new Method(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parameters]
    // Deserialize array length for message field [parameters]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.parameters = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.parameters[i] = Parameter.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [achieved_task]
    data.achieved_task = Task.deserialize(buffer, bufferOffset);
    // Deserialize message field [subtasks]
    // Deserialize array length for message field [subtasks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.subtasks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.subtasks[i] = Task.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [constraints]
    // Deserialize array length for message field [constraints]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.constraints = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.constraints[i] = Expression.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [conditions]
    // Deserialize array length for message field [conditions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.conditions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.conditions[i] = Condition.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    object.parameters.forEach((val) => {
      length += Parameter.getMessageSize(val);
    });
    length += Task.getMessageSize(object.achieved_task);
    object.subtasks.forEach((val) => {
      length += Task.getMessageSize(val);
    });
    object.constraints.forEach((val) => {
      length += Expression.getMessageSize(val);
    });
    object.conditions.forEach((val) => {
      length += Condition.getMessageSize(val);
    });
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Method';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '10cdf4f6704fb014ca7b4c22cdfaef3f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # A method describes one possible way of achieving a task.
    #
    # Example: A method that make a "move" action and recursively calls itself until reaching the destination.
    
    # A name that uniquely identify the method.
    # This is mostly used for user facing output or plan validation.
    #
    # Example: "m-recursive-goto"
    string name
    
    # Example: [robot: Robot, source: Location, intermediate: Location, destination: Location]
    Parameter[] parameters
    
    # The task that is achieved by the method.
    # A subset of the parameters of the method will typically be used to
    # define the task that is achieved.
    #
    # Example: goto(robot, destination)
    up_msgs/Task achieved_task
    
    # A set of subtasks that should be achieved to carry out the method.
    # Note that the order of subtasks is irrelevant and that any ordering constraint should be
    # specified in the `constraints` field.
    #
    # Example:
    #  - t1: (move robot source intermediate)
    #  - t2: goto(robot destination)
    up_msgs/Task[] subtasks
    
    # Constraints enable the definition of ordering constraints as well as constraints
    # on the allowed instantiation of the method's parameters.
    #
    # Example:
    #  - end(t1) < start(t2)
    #  - source != intermediate
    up_msgs/Expression[] constraints
    
    # Conjunction of conditions that must hold for the method to be applicable.
    # As for the conditions of actions, these can be temporally qualified to refer to intermediate timepoints.
    # In addition to the start/end of the method, the temporal qualification might refer to the start/end of
    # one of the subtasks using its identifier.
    #
    # Example:
    #  - [start] loc(robot) == source
    #  - [end(t1)] loc(robot) == intermediate
    #  - [end] loc(robot) == destination
    up_msgs/Condition[] conditions
    
    ================================================================================
    MSG: up_msgs/Parameter
    ## Parameter of a fluent or of an action
    
    # Name of the parameter.
    string name
    # Type of the parameter.
    string type
        
    ================================================================================
    MSG: up_msgs/Task
    ## Representation of an abstract or primitive task that should be achieved,
    ## required either in the initial task network or as a subtask of a method.
    ##
    ## Example:  task of sending a `robot` to the KITCHEN
    ##   - t1: goto(robot, KITCHEN)
    
    # Identifier of the task, required to be unique in the method/task-network where the task appears.
    # The `id` is notably used to refer to the start/end of the task.
    #
    # Example: t1
    string id
    
    # Name of the task that should be achieved. It might either
    #  - an abstract task if the name is the one of a task declared in the problem
    #  - a primitive task if the name is the one of an action declared in the problem
    #
    # Example:
    #  - "goto" (abstract task)
    #  - "move" (action / primitive task)
    string task_name
    
    # Example: (for a "goto" task)
    #  - robot    (a parameter from an outer scope)
    #  - KITCHEN  (a constant symbol in the problem)
    up_msgs/Expression[] parameters
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/Condition
    up_msgs/Expression cond
    
    # Optional. Must be set for durative actions where it specifies the temporal interval
    # over which when the condition should hold.
    # features: DURATIVE_ACTIONS
    up_msgs/TimeInterval[] span
    
    ================================================================================
    MSG: up_msgs/TimeInterval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Timing lower
    bool is_right_open
    up_msgs/Timing upper
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Method(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.parameters !== undefined) {
      resolved.parameters = new Array(msg.parameters.length);
      for (let i = 0; i < resolved.parameters.length; ++i) {
        resolved.parameters[i] = Parameter.Resolve(msg.parameters[i]);
      }
    }
    else {
      resolved.parameters = []
    }

    if (msg.achieved_task !== undefined) {
      resolved.achieved_task = Task.Resolve(msg.achieved_task)
    }
    else {
      resolved.achieved_task = new Task()
    }

    if (msg.subtasks !== undefined) {
      resolved.subtasks = new Array(msg.subtasks.length);
      for (let i = 0; i < resolved.subtasks.length; ++i) {
        resolved.subtasks[i] = Task.Resolve(msg.subtasks[i]);
      }
    }
    else {
      resolved.subtasks = []
    }

    if (msg.constraints !== undefined) {
      resolved.constraints = new Array(msg.constraints.length);
      for (let i = 0; i < resolved.constraints.length; ++i) {
        resolved.constraints[i] = Expression.Resolve(msg.constraints[i]);
      }
    }
    else {
      resolved.constraints = []
    }

    if (msg.conditions !== undefined) {
      resolved.conditions = new Array(msg.conditions.length);
      for (let i = 0; i < resolved.conditions.length; ++i) {
        resolved.conditions[i] = Condition.Resolve(msg.conditions[i]);
      }
    }
    else {
      resolved.conditions = []
    }

    return resolved;
    }
};

module.exports = Method;
