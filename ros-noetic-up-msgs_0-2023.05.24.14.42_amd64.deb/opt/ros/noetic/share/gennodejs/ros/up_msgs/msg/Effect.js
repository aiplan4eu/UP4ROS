// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let EffectExpression = require('./EffectExpression.js');
let Timing = require('./Timing.js');

//-----------------------------------------------------------

class Effect {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.effect = null;
      this.occurrence_time = null;
    }
    else {
      if (initObj.hasOwnProperty('effect')) {
        this.effect = initObj.effect
      }
      else {
        this.effect = new EffectExpression();
      }
      if (initObj.hasOwnProperty('occurrence_time')) {
        this.occurrence_time = initObj.occurrence_time
      }
      else {
        this.occurrence_time = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Effect
    // Serialize message field [effect]
    bufferOffset = EffectExpression.serialize(obj.effect, buffer, bufferOffset);
    // Serialize message field [occurrence_time]
    // Serialize the length for message field [occurrence_time]
    bufferOffset = _serializer.uint32(obj.occurrence_time.length, buffer, bufferOffset);
    obj.occurrence_time.forEach((val) => {
      bufferOffset = Timing.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Effect
    let len;
    let data = new Effect(null);
    // Deserialize message field [effect]
    data.effect = EffectExpression.deserialize(buffer, bufferOffset);
    // Deserialize message field [occurrence_time]
    // Deserialize array length for message field [occurrence_time]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.occurrence_time = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.occurrence_time[i] = Timing.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += EffectExpression.getMessageSize(object.effect);
    object.occurrence_time.forEach((val) => {
      length += Timing.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Effect';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '102cba2cc9aefab62e1d25c9e01baf2c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Representation of an effect that allows qualifying the effect expression, e.g., to make it a conditional effect.
    
    # Required. The actual effect that should take place.
    up_msgs/EffectExpression effect
    
    # Optional. If the effect is within a durative action, the following must be set and will specify when the effect takes place.
    # features: DURATIVE_ACTIONS
    up_msgs/Timing[] occurrence_time
    
    ================================================================================
    MSG: up_msgs/EffectExpression
    ## An effect expression is of the form `FLUENT OP VALUE`.
    ## We explicitly restrict the different types of effects by setting the allowed operators.
    
    # The `fluent` is set to the corresponding `value`
    uint8 ASSIGN=0
    # The `fluent` is increased by the amount `value`
    # features: INCREASE_EFFECTS
    uint8 INCREASE=1
    # The `fluent` is decreased by the amount `value`
    # features: DECREASE_EFFECTS
    uint8 DECREASE=2
    
    uint8 kind
    
    # Expression that must be of the STATE_VARIABLE kind.
    up_msgs/Expression fluent
    up_msgs/Expression value
    
    # Optional. If the effect is conditional, then the following field must be set.
    # In this case, the `effect` will only be applied if the `condition`` holds.
    # If the effect is unconditional, the effect is set to the constant 'true' value.
    # features: CONDITIONAL_EFFECT
    up_msgs/Expression condition
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Effect(null);
    if (msg.effect !== undefined) {
      resolved.effect = EffectExpression.Resolve(msg.effect)
    }
    else {
      resolved.effect = new EffectExpression()
    }

    if (msg.occurrence_time !== undefined) {
      resolved.occurrence_time = new Array(msg.occurrence_time.length);
      for (let i = 0; i < resolved.occurrence_time.length; ++i) {
        resolved.occurrence_time[i] = Timing.Resolve(msg.occurrence_time[i]);
      }
    }
    else {
      resolved.occurrence_time = []
    }

    return resolved;
    }
};

module.exports = Effect;
