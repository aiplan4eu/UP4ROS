// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Expression = require('./Expression.js');
let GoalWithCost = require('./GoalWithCost.js');

//-----------------------------------------------------------

class Metric {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.kind = null;
      this.expression = null;
      this.action_cost_names = null;
      this.action_cost_expr = null;
      this.default_action_cost = null;
      this.goals = null;
    }
    else {
      if (initObj.hasOwnProperty('kind')) {
        this.kind = initObj.kind
      }
      else {
        this.kind = 0;
      }
      if (initObj.hasOwnProperty('expression')) {
        this.expression = initObj.expression
      }
      else {
        this.expression = new Expression();
      }
      if (initObj.hasOwnProperty('action_cost_names')) {
        this.action_cost_names = initObj.action_cost_names
      }
      else {
        this.action_cost_names = [];
      }
      if (initObj.hasOwnProperty('action_cost_expr')) {
        this.action_cost_expr = initObj.action_cost_expr
      }
      else {
        this.action_cost_expr = [];
      }
      if (initObj.hasOwnProperty('default_action_cost')) {
        this.default_action_cost = initObj.default_action_cost
      }
      else {
        this.default_action_cost = [];
      }
      if (initObj.hasOwnProperty('goals')) {
        this.goals = initObj.goals
      }
      else {
        this.goals = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Metric
    // Serialize message field [kind]
    bufferOffset = _serializer.uint8(obj.kind, buffer, bufferOffset);
    // Serialize message field [expression]
    bufferOffset = Expression.serialize(obj.expression, buffer, bufferOffset);
    // Serialize message field [action_cost_names]
    bufferOffset = _arraySerializer.string(obj.action_cost_names, buffer, bufferOffset, null);
    // Serialize message field [action_cost_expr]
    // Serialize the length for message field [action_cost_expr]
    bufferOffset = _serializer.uint32(obj.action_cost_expr.length, buffer, bufferOffset);
    obj.action_cost_expr.forEach((val) => {
      bufferOffset = Expression.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [default_action_cost]
    // Serialize the length for message field [default_action_cost]
    bufferOffset = _serializer.uint32(obj.default_action_cost.length, buffer, bufferOffset);
    obj.default_action_cost.forEach((val) => {
      bufferOffset = Expression.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [goals]
    // Serialize the length for message field [goals]
    bufferOffset = _serializer.uint32(obj.goals.length, buffer, bufferOffset);
    obj.goals.forEach((val) => {
      bufferOffset = GoalWithCost.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Metric
    let len;
    let data = new Metric(null);
    // Deserialize message field [kind]
    data.kind = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [expression]
    data.expression = Expression.deserialize(buffer, bufferOffset);
    // Deserialize message field [action_cost_names]
    data.action_cost_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [action_cost_expr]
    // Deserialize array length for message field [action_cost_expr]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.action_cost_expr = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.action_cost_expr[i] = Expression.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [default_action_cost]
    // Deserialize array length for message field [default_action_cost]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.default_action_cost = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.default_action_cost[i] = Expression.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [goals]
    // Deserialize array length for message field [goals]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.goals = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.goals[i] = GoalWithCost.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Expression.getMessageSize(object.expression);
    object.action_cost_names.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.action_cost_expr.forEach((val) => {
      length += Expression.getMessageSize(val);
    });
    object.default_action_cost.forEach((val) => {
      length += Expression.getMessageSize(val);
    });
    object.goals.forEach((val) => {
      length += GoalWithCost.getMessageSize(val);
    });
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Metric';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e8669c86dbbce33ac938cbfc865fca5c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    # Minimize the action costs expressed in the `action_costs` field
    uint8 MINIMIZE_ACTION_COSTS=0
    
    # Minimize the length of the resulting sequential plan
    uint8 MINIMIZE_SEQUENTIAL_PLAN_LENGTH=1
    
    # Minimize the makespan in case of temporal planning
    # features: durative_actions
    uint8 MINIMIZE_MAKESPAN=2
    
    # Minimize the value of the expression defined in the `expression` field
    uint8 MINIMIZE_EXPRESSION_ON_FINAL_STATE=3
    
    # Maximize the value of the expression defined in the `expression` field
    uint8 MAXIMIZE_EXPRESSION_ON_FINAL_STATE=4
    
    # Maximize the number of goals reached, weighted by cost
    uint8 OVERSUBSCRIPTION=5
        
    uint8 kind
    
    
    # Expression to minimize/maximize in the final state.
    # Empty, if the `kind` is not {MIN/MAX}IMIZE_EXPRESSION_ON_FINAL_STATE
    Expression expression
    
    # If `kind == MINIMIZE_ACTION_COSTS``, then each action is associated to a cost expression.
    #
    # TODO: Document what is allowed in the expression. See issue #134
    # In particular, for this metric to be useful in many practical problems, the cost expression
    # should allow referring to the action parameters (and possibly the current state at the action start/end).
    # This is very awkward to do in this setting where the expression is detached from its scope.
    string[] action_cost_names
    up_msgs/Expression[] action_cost_expr
    
    up_msgs/Expression[] default_action_cost
    
    # List of goals used to define the oversubscription planning problem.
    # Empty, if the `kind` is not OVERSUBSCRIPTION
    up_msgs/GoalWithCost[] goals
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/GoalWithCost
    ## Represents a goal associated with a cost, used to define oversubscription planning.
    
    # Goal expression
    up_msgs/Expression goal
    # The cost
    up_msgs/Real cost
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Metric(null);
    if (msg.kind !== undefined) {
      resolved.kind = msg.kind;
    }
    else {
      resolved.kind = 0
    }

    if (msg.expression !== undefined) {
      resolved.expression = Expression.Resolve(msg.expression)
    }
    else {
      resolved.expression = new Expression()
    }

    if (msg.action_cost_names !== undefined) {
      resolved.action_cost_names = msg.action_cost_names;
    }
    else {
      resolved.action_cost_names = []
    }

    if (msg.action_cost_expr !== undefined) {
      resolved.action_cost_expr = new Array(msg.action_cost_expr.length);
      for (let i = 0; i < resolved.action_cost_expr.length; ++i) {
        resolved.action_cost_expr[i] = Expression.Resolve(msg.action_cost_expr[i]);
      }
    }
    else {
      resolved.action_cost_expr = []
    }

    if (msg.default_action_cost !== undefined) {
      resolved.default_action_cost = new Array(msg.default_action_cost.length);
      for (let i = 0; i < resolved.default_action_cost.length; ++i) {
        resolved.default_action_cost[i] = Expression.Resolve(msg.default_action_cost[i]);
      }
    }
    else {
      resolved.default_action_cost = []
    }

    if (msg.goals !== undefined) {
      resolved.goals = new Array(msg.goals.length);
      for (let i = 0; i < resolved.goals.length; ++i) {
        resolved.goals[i] = GoalWithCost.Resolve(msg.goals[i]);
      }
    }
    else {
      resolved.goals = []
    }

    return resolved;
    }
};

// Constants for message
Metric.Constants = {
  MINIMIZE_ACTION_COSTS: 0,
  MINIMIZE_SEQUENTIAL_PLAN_LENGTH: 1,
  MINIMIZE_MAKESPAN: 2,
  MINIMIZE_EXPRESSION_ON_FINAL_STATE: 3,
  MAXIMIZE_EXPRESSION_ON_FINAL_STATE: 4,
  OVERSUBSCRIPTION: 5,
}

module.exports = Metric;
