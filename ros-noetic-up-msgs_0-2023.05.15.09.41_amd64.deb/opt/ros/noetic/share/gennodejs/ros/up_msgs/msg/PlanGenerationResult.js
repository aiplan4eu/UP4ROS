// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Plan = require('./Plan.js');
let LogMessage = require('./LogMessage.js');

//-----------------------------------------------------------

class PlanGenerationResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
      this.plan = null;
      this.metric_names = null;
      this.metric_values = null;
      this.log_messages = null;
      this.engine_name = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('plan')) {
        this.plan = initObj.plan
      }
      else {
        this.plan = new Plan();
      }
      if (initObj.hasOwnProperty('metric_names')) {
        this.metric_names = initObj.metric_names
      }
      else {
        this.metric_names = [];
      }
      if (initObj.hasOwnProperty('metric_values')) {
        this.metric_values = initObj.metric_values
      }
      else {
        this.metric_values = [];
      }
      if (initObj.hasOwnProperty('log_messages')) {
        this.log_messages = initObj.log_messages
      }
      else {
        this.log_messages = [];
      }
      if (initObj.hasOwnProperty('engine_name')) {
        this.engine_name = initObj.engine_name
      }
      else {
        this.engine_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlanGenerationResult
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [plan]
    bufferOffset = Plan.serialize(obj.plan, buffer, bufferOffset);
    // Serialize message field [metric_names]
    bufferOffset = _arraySerializer.string(obj.metric_names, buffer, bufferOffset, null);
    // Serialize message field [metric_values]
    bufferOffset = _arraySerializer.string(obj.metric_values, buffer, bufferOffset, null);
    // Serialize message field [log_messages]
    // Serialize the length for message field [log_messages]
    bufferOffset = _serializer.uint32(obj.log_messages.length, buffer, bufferOffset);
    obj.log_messages.forEach((val) => {
      bufferOffset = LogMessage.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [engine_name]
    bufferOffset = _serializer.string(obj.engine_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlanGenerationResult
    let len;
    let data = new PlanGenerationResult(null);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [plan]
    data.plan = Plan.deserialize(buffer, bufferOffset);
    // Deserialize message field [metric_names]
    data.metric_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [metric_values]
    data.metric_values = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [log_messages]
    // Deserialize array length for message field [log_messages]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.log_messages = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.log_messages[i] = LogMessage.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [engine_name]
    data.engine_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Plan.getMessageSize(object.plan);
    object.metric_names.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.metric_values.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.log_messages.forEach((val) => {
      length += LogMessage.getMessageSize(val);
    });
    length += _getByteLength(object.engine_name);
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/PlanGenerationResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '06a3946e2ae91fa7761d9e164ba4420b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Message sent by engine.
    ## Contains the engine exit status as well as the best plan found if any.
    
    
    # ==== Engine stopped normally ======
    
    # Valid plan found
    # The `plan` field must be set.
    uint8 SOLVED_SATISFICING=0
    # Plan found with optimality guarantee
    # The `plan` field must be set and contains an optimal solution.
    uint8 SOLVED_OPTIMALLY=1
    # No plan exists
    uint8 UNSOLVABLE_PROVEN=2
    # The engine was not able to find a solution but does not give any guarantee that none exist
    # (i.e. the engine might not be complete)
    uint8 UNSOLVABLE_INCOMPLETELY=3
    
    # ====== Engine exited before making any conclusion ====
    # Search stopped before concluding SOLVED_OPTIMALLY or UNSOLVABLE_PROVEN
    # If a plan was found, it might be reported in the `plan` field
    
    # The engine ran out of time
    uint8 TIMEOUT=13
    # The engine ran out of memory
    uint8 MEMOUT=14
    # The engine faced an internal error.
    uint8 INTERNAL_ERROR=15
    # The problem submitted is not supported by the engine.
    uint8 UNSUPPORTED_PROBLEM=16
    
    # ====== Intermediate answer ======
    # This Answer is an Intermediate Answer and not a Final one
    uint8 INTERMEDIATE=17
    
    uint8 status
    
    # Optional. Best plan found if any.
    up_msgs/Plan plan
    
    # A set of engine specific values that can be reported, for instance
    # - "grounding-time": "10ms"
    # - "expanded-states": "1290"
    string[] metric_names
    string[] metric_values
    
    # Optional log messages about the engine's activity.
    # Note that it should not be expected that logging messages are visible to the end user.
    # If used in conjunction with INTERNAL_ERROR or UNSUPPORTED_PROBLEM, it would be expected to have at least one log message at the ERROR level.
    up_msgs/LogMessage[] log_messages
    
    # Synthetic description of the engine that generated this message.
    string engine_name
    
    ================================================================================
    MSG: up_msgs/Plan
    # An ordered sequence of actions that appear in the plan.
    # The order of the actions in the list must be compatible with the partial order of the start times.
    # In case of non-temporal planning, this allows having all start time at 0 and only rely on the order in this sequence.
        
    up_msgs/ActionInstance[] actions
    
    ================================================================================
    MSG: up_msgs/ActionInstance
    ## Representation of an action instance that appears in a plan.
    
    # Optional. A unique identifier of the action that might be used to refer to it (e.g. in HTN plans).
    string id
    # name of the action
    string action_name
    # Parameters of the action instance, required to be constants.
    up_msgs/Atom[] parameters
    
    bool time_triggered
    
    # Start time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real start_time
    # End time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real end_time
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/LogMessage
    ## A freely formatted logging message.
    ## Each message is annotated with its criticality level from the minimal (DEBUG) to the maximal (ERROR).
    ## Criticality level is expected to be used by an end user to decide the level of verbosity.
    
    uint8 DEBUG=0
    uint8 INFO=1
    uint8 WARNING=2
    uint8 ERROR=3
    
    uint8 level
    string message
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlanGenerationResult(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.plan !== undefined) {
      resolved.plan = Plan.Resolve(msg.plan)
    }
    else {
      resolved.plan = new Plan()
    }

    if (msg.metric_names !== undefined) {
      resolved.metric_names = msg.metric_names;
    }
    else {
      resolved.metric_names = []
    }

    if (msg.metric_values !== undefined) {
      resolved.metric_values = msg.metric_values;
    }
    else {
      resolved.metric_values = []
    }

    if (msg.log_messages !== undefined) {
      resolved.log_messages = new Array(msg.log_messages.length);
      for (let i = 0; i < resolved.log_messages.length; ++i) {
        resolved.log_messages[i] = LogMessage.Resolve(msg.log_messages[i]);
      }
    }
    else {
      resolved.log_messages = []
    }

    if (msg.engine_name !== undefined) {
      resolved.engine_name = msg.engine_name;
    }
    else {
      resolved.engine_name = ''
    }

    return resolved;
    }
};

// Constants for message
PlanGenerationResult.Constants = {
  SOLVED_SATISFICING: 0,
  SOLVED_OPTIMALLY: 1,
  UNSOLVABLE_PROVEN: 2,
  UNSOLVABLE_INCOMPLETELY: 3,
  TIMEOUT: 13,
  MEMOUT: 14,
  INTERNAL_ERROR: 15,
  UNSUPPORTED_PROBLEM: 16,
  INTERMEDIATE: 17,
}

module.exports = PlanGenerationResult;
