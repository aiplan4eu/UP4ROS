// Auto-generated. Do not edit!

// (in-package up_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Action = require('../msg/Action.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class AddActionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.problem_name = null;
      this.action = null;
    }
    else {
      if (initObj.hasOwnProperty('problem_name')) {
        this.problem_name = initObj.problem_name
      }
      else {
        this.problem_name = '';
      }
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = new Action();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AddActionRequest
    // Serialize message field [problem_name]
    bufferOffset = _serializer.string(obj.problem_name, buffer, bufferOffset);
    // Serialize message field [action]
    bufferOffset = Action.serialize(obj.action, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AddActionRequest
    let len;
    let data = new AddActionRequest(null);
    // Deserialize message field [problem_name]
    data.problem_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [action]
    data.action = Action.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.problem_name);
    length += Action.getMessageSize(object.action);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/AddActionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '31693e663fd4cc36e66ee977aba27227';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string problem_name
    up_msgs/Action action
    
    ================================================================================
    MSG: up_msgs/Action
    ## Unified action representation that represents any kind of actions.
    
    # Action name. E.g. "move"
    string name
    
    # Typed and named parameters of the action.
    up_msgs/Parameter[] parameters
    
    # If set, the action is durative. Otherwise it is instantaneous.
    # features: DURATIVE_ACTIONS
    up_msgs/Duration[] duration
    
    # Conjunction of conditions that must hold for the action to be applicable.
    up_msgs/Condition[] conditions
    
    # Conjunction of effects as a result of applying this action.
    up_msgs/Effect[] effects
    
    ================================================================================
    MSG: up_msgs/Parameter
    ## Parameter of a fluent or of an action
    
    # Name of the parameter.
    string name
    # Type of the parameter.
    string type
        
    ================================================================================
    MSG: up_msgs/Duration
    # The duration of the action can be freely chosen within the indicated bounds
    up_msgs/Interval controllable_in_bounds
    
    ================================================================================
    MSG: up_msgs/Interval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Expression lower
    bool is_right_open
    up_msgs/Expression upper
    
    ================================================================================
    MSG: up_msgs/Expression
    up_msgs/ExpressionItem[] expressions
    uint8[] level
    
    ================================================================================
    MSG: up_msgs/ExpressionItem
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    ================================================================================
    MSG: up_msgs/Condition
    up_msgs/Expression cond
    
    # Optional. Must be set for durative actions where it specifies the temporal interval
    # over which when the condition should hold.
    # features: DURATIVE_ACTIONS
    up_msgs/TimeInterval[] span
    
    ================================================================================
    MSG: up_msgs/TimeInterval
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Timing lower
    bool is_right_open
    up_msgs/Timing upper
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    ================================================================================
    MSG: up_msgs/Effect
    ## Representation of an effect that allows qualifying the effect expression, e.g., to make it a conditional effect.
    
    # Required. The actual effect that should take place.
    up_msgs/EffectExpression effect
    
    # Optional. If the effect is within a durative action, the following must be set and will specify when the effect takes place.
    # features: DURATIVE_ACTIONS
    up_msgs/Timing[] occurrence_time
    
    ================================================================================
    MSG: up_msgs/EffectExpression
    ## An effect expression is of the form `FLUENT OP VALUE`.
    ## We explicitly restrict the different types of effects by setting the allowed operators.
    
    # The `fluent` is set to the corresponding `value`
    uint8 ASSIGN=0
    # The `fluent` is increased by the amount `value`
    # features: INCREASE_EFFECTS
    uint8 INCREASE=1
    # The `fluent` is decreased by the amount `value`
    # features: DECREASE_EFFECTS
    uint8 DECREASE=2
    
    uint8 kind
    
    # Expression that must be of the STATE_VARIABLE kind.
    up_msgs/Expression fluent
    up_msgs/Expression value
    
    # Optional. If the effect is conditional, then the following field must be set.
    # In this case, the `effect` will only be applied if the `condition`` holds.
    # If the effect is unconditional, the effect is set to the constant 'true' value.
    # features: CONDITIONAL_EFFECT
    up_msgs/Expression condition
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AddActionRequest(null);
    if (msg.problem_name !== undefined) {
      resolved.problem_name = msg.problem_name;
    }
    else {
      resolved.problem_name = ''
    }

    if (msg.action !== undefined) {
      resolved.action = Action.Resolve(msg.action)
    }
    else {
      resolved.action = new Action()
    }

    return resolved;
    }
};

class AddActionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AddActionResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AddActionResponse
    let len;
    let data = new AddActionResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'up_msgs/AddActionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AddActionResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: AddActionRequest,
  Response: AddActionResponse,
  md5sum() { return 'da5584f9fbd99ac765de548f518c17f2'; },
  datatype() { return 'up_msgs/AddAction'; }
};
