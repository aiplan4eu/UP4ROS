// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Atom = require('./Atom.js');
let Real = require('./Real.js');

//-----------------------------------------------------------

class ActionInstance {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.action_name = null;
      this.parameters = null;
      this.time_triggered = null;
      this.start_time = null;
      this.end_time = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = '';
      }
      if (initObj.hasOwnProperty('action_name')) {
        this.action_name = initObj.action_name
      }
      else {
        this.action_name = '';
      }
      if (initObj.hasOwnProperty('parameters')) {
        this.parameters = initObj.parameters
      }
      else {
        this.parameters = [];
      }
      if (initObj.hasOwnProperty('time_triggered')) {
        this.time_triggered = initObj.time_triggered
      }
      else {
        this.time_triggered = false;
      }
      if (initObj.hasOwnProperty('start_time')) {
        this.start_time = initObj.start_time
      }
      else {
        this.start_time = new Real();
      }
      if (initObj.hasOwnProperty('end_time')) {
        this.end_time = initObj.end_time
      }
      else {
        this.end_time = new Real();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ActionInstance
    // Serialize message field [id]
    bufferOffset = _serializer.string(obj.id, buffer, bufferOffset);
    // Serialize message field [action_name]
    bufferOffset = _serializer.string(obj.action_name, buffer, bufferOffset);
    // Serialize message field [parameters]
    // Serialize the length for message field [parameters]
    bufferOffset = _serializer.uint32(obj.parameters.length, buffer, bufferOffset);
    obj.parameters.forEach((val) => {
      bufferOffset = Atom.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [time_triggered]
    bufferOffset = _serializer.bool(obj.time_triggered, buffer, bufferOffset);
    // Serialize message field [start_time]
    bufferOffset = Real.serialize(obj.start_time, buffer, bufferOffset);
    // Serialize message field [end_time]
    bufferOffset = Real.serialize(obj.end_time, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ActionInstance
    let len;
    let data = new ActionInstance(null);
    // Deserialize message field [id]
    data.id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [action_name]
    data.action_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parameters]
    // Deserialize array length for message field [parameters]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.parameters = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.parameters[i] = Atom.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [time_triggered]
    data.time_triggered = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [start_time]
    data.start_time = Real.deserialize(buffer, bufferOffset);
    // Deserialize message field [end_time]
    data.end_time = Real.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.id);
    length += _getByteLength(object.action_name);
    object.parameters.forEach((val) => {
      length += Atom.getMessageSize(val);
    });
    return length + 45;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/ActionInstance';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '98e648e17a180880571d0dce4ae74d0f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Representation of an action instance that appears in a plan.
    
    # Optional. A unique identifier of the action that might be used to refer to it (e.g. in HTN plans).
    string id
    # name of the action
    string action_name
    # Parameters of the action instance, required to be constants.
    up_msgs/Atom[] parameters
    
    bool time_triggered
    
    # Start time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real start_time
    # End time of the action. The default 0 value is OK in the case of non-temporal planning
    # feature: [DURATIVE_ACTIONS]
    up_msgs/Real end_time
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ActionInstance(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = ''
    }

    if (msg.action_name !== undefined) {
      resolved.action_name = msg.action_name;
    }
    else {
      resolved.action_name = ''
    }

    if (msg.parameters !== undefined) {
      resolved.parameters = new Array(msg.parameters.length);
      for (let i = 0; i < resolved.parameters.length; ++i) {
        resolved.parameters[i] = Atom.Resolve(msg.parameters[i]);
      }
    }
    else {
      resolved.parameters = []
    }

    if (msg.time_triggered !== undefined) {
      resolved.time_triggered = msg.time_triggered;
    }
    else {
      resolved.time_triggered = false
    }

    if (msg.start_time !== undefined) {
      resolved.start_time = Real.Resolve(msg.start_time)
    }
    else {
      resolved.start_time = new Real()
    }

    if (msg.end_time !== undefined) {
      resolved.end_time = Real.Resolve(msg.end_time)
    }
    else {
      resolved.end_time = new Real()
    }

    return resolved;
    }
};

module.exports = ActionInstance;
