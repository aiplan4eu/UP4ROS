// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Timing = require('./Timing.js');

//-----------------------------------------------------------

class TimeInterval {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_left_open = null;
      this.lower = null;
      this.is_right_open = null;
      this.upper = null;
    }
    else {
      if (initObj.hasOwnProperty('is_left_open')) {
        this.is_left_open = initObj.is_left_open
      }
      else {
        this.is_left_open = false;
      }
      if (initObj.hasOwnProperty('lower')) {
        this.lower = initObj.lower
      }
      else {
        this.lower = new Timing();
      }
      if (initObj.hasOwnProperty('is_right_open')) {
        this.is_right_open = initObj.is_right_open
      }
      else {
        this.is_right_open = false;
      }
      if (initObj.hasOwnProperty('upper')) {
        this.upper = initObj.upper
      }
      else {
        this.upper = new Timing();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TimeInterval
    // Serialize message field [is_left_open]
    bufferOffset = _serializer.bool(obj.is_left_open, buffer, bufferOffset);
    // Serialize message field [lower]
    bufferOffset = Timing.serialize(obj.lower, buffer, bufferOffset);
    // Serialize message field [is_right_open]
    bufferOffset = _serializer.bool(obj.is_right_open, buffer, bufferOffset);
    // Serialize message field [upper]
    bufferOffset = Timing.serialize(obj.upper, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TimeInterval
    let len;
    let data = new TimeInterval(null);
    // Deserialize message field [is_left_open]
    data.is_left_open = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [lower]
    data.lower = Timing.deserialize(buffer, bufferOffset);
    // Deserialize message field [is_right_open]
    data.is_right_open = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [upper]
    data.upper = Timing.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Timing.getMessageSize(object.lower);
    length += Timing.getMessageSize(object.upper);
    return length + 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/TimeInterval';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd3b1c5ab8a7be2ed26739f49c6aa8588';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## A contiguous slice of time represented as an interval `[lower, upper]` where `lower` and `upper` are time references.
    ## The `is_left_open` and `is_right_open` fields indicate whether the interval is
    ## opened on left and right side respectively.
    
    bool is_left_open
    up_msgs/Timing lower
    bool is_right_open
    up_msgs/Timing upper
    
    ================================================================================
    MSG: up_msgs/Timing
    ## Represents a time (`timepoint` + `delay`), that is a time defined relatively to a particular `timepoint`.
    ## Note that an absolute time can be defined by setting the `delay` relative to the `GLOBAL_START`` which is the reference time.
    
    up_msgs/Timepoint timepoint
    up_msgs/Real[] delay
    
    
    ================================================================================
    MSG: up_msgs/Timepoint
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TimeInterval(null);
    if (msg.is_left_open !== undefined) {
      resolved.is_left_open = msg.is_left_open;
    }
    else {
      resolved.is_left_open = false
    }

    if (msg.lower !== undefined) {
      resolved.lower = Timing.Resolve(msg.lower)
    }
    else {
      resolved.lower = new Timing()
    }

    if (msg.is_right_open !== undefined) {
      resolved.is_right_open = msg.is_right_open;
    }
    else {
      resolved.is_right_open = false
    }

    if (msg.upper !== undefined) {
      resolved.upper = Timing.Resolve(msg.upper)
    }
    else {
      resolved.upper = new Timing()
    }

    return resolved;
    }
};

module.exports = TimeInterval;
