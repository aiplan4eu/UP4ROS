// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Real = require('./Real.js');

//-----------------------------------------------------------

class Atom {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.symbol_atom = null;
      this.int_atom = null;
      this.real_atom = null;
      this.boolean_atom = null;
    }
    else {
      if (initObj.hasOwnProperty('symbol_atom')) {
        this.symbol_atom = initObj.symbol_atom
      }
      else {
        this.symbol_atom = [];
      }
      if (initObj.hasOwnProperty('int_atom')) {
        this.int_atom = initObj.int_atom
      }
      else {
        this.int_atom = [];
      }
      if (initObj.hasOwnProperty('real_atom')) {
        this.real_atom = initObj.real_atom
      }
      else {
        this.real_atom = [];
      }
      if (initObj.hasOwnProperty('boolean_atom')) {
        this.boolean_atom = initObj.boolean_atom
      }
      else {
        this.boolean_atom = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Atom
    // Serialize message field [symbol_atom]
    bufferOffset = _arraySerializer.string(obj.symbol_atom, buffer, bufferOffset, null);
    // Serialize message field [int_atom]
    bufferOffset = _arraySerializer.int64(obj.int_atom, buffer, bufferOffset, null);
    // Serialize message field [real_atom]
    // Serialize the length for message field [real_atom]
    bufferOffset = _serializer.uint32(obj.real_atom.length, buffer, bufferOffset);
    obj.real_atom.forEach((val) => {
      bufferOffset = Real.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [boolean_atom]
    bufferOffset = _arraySerializer.bool(obj.boolean_atom, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Atom
    let len;
    let data = new Atom(null);
    // Deserialize message field [symbol_atom]
    data.symbol_atom = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [int_atom]
    data.int_atom = _arrayDeserializer.int64(buffer, bufferOffset, null)
    // Deserialize message field [real_atom]
    // Deserialize array length for message field [real_atom]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.real_atom = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.real_atom[i] = Real.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [boolean_atom]
    data.boolean_atom = _arrayDeserializer.bool(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.symbol_atom.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 8 * object.int_atom.length;
    length += 16 * object.real_atom.length;
    length += object.boolean_atom.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Atom';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c84565cfa88b748e265f6f86e63e6223';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Atom(null);
    if (msg.symbol_atom !== undefined) {
      resolved.symbol_atom = msg.symbol_atom;
    }
    else {
      resolved.symbol_atom = []
    }

    if (msg.int_atom !== undefined) {
      resolved.int_atom = msg.int_atom;
    }
    else {
      resolved.int_atom = []
    }

    if (msg.real_atom !== undefined) {
      resolved.real_atom = new Array(msg.real_atom.length);
      for (let i = 0; i < resolved.real_atom.length; ++i) {
        resolved.real_atom[i] = Real.Resolve(msg.real_atom[i]);
      }
    }
    else {
      resolved.real_atom = []
    }

    if (msg.boolean_atom !== undefined) {
      resolved.boolean_atom = msg.boolean_atom;
    }
    else {
      resolved.boolean_atom = []
    }

    return resolved;
    }
};

module.exports = Atom;
