// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TypeDeclaration {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type_name = null;
      this.parent_type = null;
    }
    else {
      if (initObj.hasOwnProperty('type_name')) {
        this.type_name = initObj.type_name
      }
      else {
        this.type_name = '';
      }
      if (initObj.hasOwnProperty('parent_type')) {
        this.parent_type = initObj.parent_type
      }
      else {
        this.parent_type = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TypeDeclaration
    // Serialize message field [type_name]
    bufferOffset = _serializer.string(obj.type_name, buffer, bufferOffset);
    // Serialize message field [parent_type]
    bufferOffset = _serializer.string(obj.parent_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TypeDeclaration
    let len;
    let data = new TypeDeclaration(null);
    // Deserialize message field [type_name]
    data.type_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parent_type]
    data.parent_type = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.type_name);
    length += _getByteLength(object.parent_type);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/TypeDeclaration';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '16468f2f988c81c9c87d4130d6c84494';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Declares the existence of a symbolic type.
    
    # Name of the type that is declared.
    string type_name
    
    # Optional. If the string is non-empty, this is the parent type of `type_name`.
    # If set, the parent type must have been previously declared (i.e. should appear earlier in the problem's type declarations.
    # feature: HIERARCHICAL_TYPING
    string parent_type
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TypeDeclaration(null);
    if (msg.type_name !== undefined) {
      resolved.type_name = msg.type_name;
    }
    else {
      resolved.type_name = ''
    }

    if (msg.parent_type !== undefined) {
      resolved.parent_type = msg.parent_type;
    }
    else {
      resolved.parent_type = ''
    }

    return resolved;
    }
};

module.exports = TypeDeclaration;
