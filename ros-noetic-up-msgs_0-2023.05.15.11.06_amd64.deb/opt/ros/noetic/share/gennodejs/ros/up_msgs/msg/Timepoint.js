// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Timepoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.kind = null;
      this.container_id = null;
    }
    else {
      if (initObj.hasOwnProperty('kind')) {
        this.kind = initObj.kind
      }
      else {
        this.kind = 0;
      }
      if (initObj.hasOwnProperty('container_id')) {
        this.container_id = initObj.container_id
      }
      else {
        this.container_id = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Timepoint
    // Serialize message field [kind]
    bufferOffset = _serializer.uint8(obj.kind, buffer, bufferOffset);
    // Serialize message field [container_id]
    bufferOffset = _serializer.string(obj.container_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Timepoint
    let len;
    let data = new Timepoint(null);
    // Deserialize message field [kind]
    data.kind = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [container_id]
    data.container_id = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.container_id);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/Timepoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '34f5fd83563157fba6d2e84644a3858f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## Symbolic reference to an absolute time.
    ## It might represent:
    ## - the time of the initial/final state, or
    ## - the start/end of the containing action.
    ##
    ## It is currently composed of a single field whose interpretation might be context dependent
    ## (e.g. "START" refers to the start of the containing action).
    ##
    ## In the future, it could be extended to refer, e.g., to the start of a particular action/subtask
    ## by adding an additional field with the identifier of an action/subtask.
    
    # Global start of the planning problem. This is context independent and represents the time at which the initial state holds.
    uint8 GLOBAL_START=0
    # Global end of the planning problem. This is context independent and represents the time at which the final state holds.
    uint8 GLOBAL_END=1
    # Start of the container (typically the action or method) in which this symbol occurs
    uint8 START=2
    # End of the container (typically the action or method) in which this symbol occurs
    uint8 END=3
    
    uint8 kind
    
    # If non-empty, identifies the container of which we are extracting the start/end timepoint.
    # In the context of a task-network or of a method, this could be the `id` of one of the subtasks.
    # feature: hierarchies
    string container_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Timepoint(null);
    if (msg.kind !== undefined) {
      resolved.kind = msg.kind;
    }
    else {
      resolved.kind = 0
    }

    if (msg.container_id !== undefined) {
      resolved.container_id = msg.container_id;
    }
    else {
      resolved.container_id = ''
    }

    return resolved;
    }
};

// Constants for message
Timepoint.Constants = {
  GLOBAL_START: 0,
  GLOBAL_END: 1,
  START: 2,
  END: 3,
}

module.exports = Timepoint;
