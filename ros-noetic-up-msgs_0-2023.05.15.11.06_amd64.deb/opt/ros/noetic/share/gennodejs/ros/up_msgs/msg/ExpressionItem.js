// Auto-generated. Do not edit!

// (in-package up_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Atom = require('./Atom.js');

//-----------------------------------------------------------

class ExpressionItem {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.atom = null;
      this.type = null;
      this.kind = null;
    }
    else {
      if (initObj.hasOwnProperty('atom')) {
        this.atom = initObj.atom
      }
      else {
        this.atom = [];
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = '';
      }
      if (initObj.hasOwnProperty('kind')) {
        this.kind = initObj.kind
      }
      else {
        this.kind = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExpressionItem
    // Serialize message field [atom]
    // Serialize the length for message field [atom]
    bufferOffset = _serializer.uint32(obj.atom.length, buffer, bufferOffset);
    obj.atom.forEach((val) => {
      bufferOffset = Atom.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [type]
    bufferOffset = _serializer.string(obj.type, buffer, bufferOffset);
    // Serialize message field [kind]
    bufferOffset = _serializer.uint8(obj.kind, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExpressionItem
    let len;
    let data = new ExpressionItem(null);
    // Deserialize message field [atom]
    // Deserialize array length for message field [atom]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.atom = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.atom[i] = Atom.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [type]
    data.type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [kind]
    data.kind = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.atom.forEach((val) => {
      length += Atom.getMessageSize(val);
    });
    length += _getByteLength(object.type);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'up_msgs/ExpressionItem';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9551074fa7214ecacec9e379b1d68de6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ## The kind of an expression, which gives information related to its structure.
    
    # If non-empty, the expression is a single atom.
    # For instance `3`, `+`, `kitchen`, `at-robot`, ...
    up_msgs/Atom[] atom
    # If the `atom` field is empty, then the expression is a list of sub-expressions,
    # typically representing the application of some arguments to a function or fluent.
    # For instance `(+ 1 3)`, (at-robot l1)`, `(>= (battery_level) 20)`
    
    # Type of the expression. For instance "int", "location", ...
    string type
    
    # Kind of the expression, specifying the content of the expression.
    # This is intended to facilitate parsing of the expression.
        
    # Default value, should not be used. Drop it if we are sure to never need it.
    uint8 UNKNOWN=0
    
    # Constant atom. For instance `3` or `kitchen` (where `kitchen` is an object defined in the problem)
    uint8 CONSTANT=1
    
    # Atom symbol representing a parameter from an outer scope. For instance `from` that would appear inside a `(move from to - location)` action.
    uint8 PARAMETER=2
    
    # Atom symbol representing a variable from an outer scope.
    # This is typically used to represent the variables that are existentially or universally qualified in expressions.
    uint8 VARIABLE=7
    
    # Atom symbol representing a fluent of the problem. For instance `at-robot`.
    uint8 FLUENT_SYMBOL=3
    
    # Atom representing a function. For instance `+`, `=`, `and`, ...
    uint8 FUNCTION_SYMBOL=4
    
    # List. Application of some parameters to a fluent symbol. For instance `(at-robot l1)` or `(battery-charged)`
    # The first element of the list must be a FLUENT_SYMBOL
    uint8 STATE_VARIABLE=5
    
    # List. The expression is the application of some parameters to a function. For instance `(+ 1 3)`.
    # The first element of the list must be a FUNCTION_SYMBOL
    uint8 FUNCTION_APPLICATION=6
    
    # Atom symbol. Unique identifier of a task or action in the current scope.
    uint8 CONTAINER_ID=8
    
    uint8 kind
    
    ================================================================================
    MSG: up_msgs/Atom
    string[] symbol_atom
    int64[] int_atom
    up_msgs/Real[] real_atom
    bool[] boolean_atom
    
    ================================================================================
    MSG: up_msgs/Real
    ## Representation of a constant real number, as the fraction `(numerator / denominator)`.
    ## A real should be in its canonical form (with smallest possible denominator).
    ## Notably, if this number is an integer, then it is guaranteed that `denominator == 1`.
    
    int64 numerator
    int64 denominator
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExpressionItem(null);
    if (msg.atom !== undefined) {
      resolved.atom = new Array(msg.atom.length);
      for (let i = 0; i < resolved.atom.length; ++i) {
        resolved.atom[i] = Atom.Resolve(msg.atom[i]);
      }
    }
    else {
      resolved.atom = []
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = ''
    }

    if (msg.kind !== undefined) {
      resolved.kind = msg.kind;
    }
    else {
      resolved.kind = 0
    }

    return resolved;
    }
};

// Constants for message
ExpressionItem.Constants = {
  UNKNOWN: 0,
  CONSTANT: 1,
  PARAMETER: 2,
  VARIABLE: 7,
  FLUENT_SYMBOL: 3,
  FUNCTION_SYMBOL: 4,
  STATE_VARIABLE: 5,
  FUNCTION_APPLICATION: 6,
  CONTAINER_ID: 8,
}

module.exports = ExpressionItem;
